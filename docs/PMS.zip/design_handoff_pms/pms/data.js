// Shared seed data — matches the seed prompt 1:1
window.PMS_DATA = (function(){
  const BIZ_DATE = "2026-04-20"; // Monday
  const HOTEL = { name: "Grand Baltic Hotel", rooms: 184, currency: "₽" };

  // ROOMS breakdown
  const ROOM_TYPES = [
    { code: "STD",   name: "Standard",      total: 80, occ: 52 },
    { code: "TWN",   name: "Twin",          total: 30, occ: 18 },
    { code: "DLX",   name: "Deluxe",        total: 40, occ: 28 },
    { code: "JR",    name: "Junior Suite",  total: 24, occ: 14 },
    { code: "SUITE", name: "Suite",         total: 10, occ: 6  },
  ];

  // HK summary
  const HK = { dirty: 42, clean: 96, pickup: 18, inspected: 28, ooo: 4, oos: 2 };

  // Day KPIs
  const KPI = {
    occupancy: 64, adr: 7400, revpar: 4736, guests: 245, rooms_sold: 118,
    arrivals: 12, departures: 9, in_house: 118,
    rooms_ooo: 4, rooms_oos: 2,
    adr_delta: +3.2, occ_delta: +5, revpar_delta: +8.9,
  };

  // Due In (arrivals today) — 12 bookings
  const ARRIVALS = [
    { conf:"BK-24018", g:"Иванов А.П.",    vip:true,  room:"508", type:"SUITE", eta:"15:00", nights:1, st:"confirmed",   src:"Booking.com", rate:"BAR",  adults:2, rate_amt:18900 },
    { conf:"BK-24017", g:"Петров С.И.",    vip:false, room:"305", type:"STD",   eta:"14:30", nights:2, st:"confirmed",   src:"Прямой",      rate:"BAR",  adults:1, rate_amt:6200 },
    { conf:"BK-24019", g:"Козлова М.В.",   vip:false, room:"412", type:"DLX",   eta:"14:00", nights:2, st:"checked-in", src:"Ostrovok",    rate:"CORP", adults:2, rate_amt:9800 },
    { conf:"BK-24020", g:"Смирнов Д.К.",   vip:false, room:"221", type:"STD",   eta:"15:30", nights:3, st:"confirmed",   src:"Прямой",      rate:"BAR",  adults:2, rate_amt:6400 },
    { conf:"BK-24021", g:"Fischer K.",     vip:false, room:"610", type:"JR",    eta:"16:00", nights:2, st:"confirmed",   src:"Expedia",     rate:"BAR",  adults:2, rate_amt:11200 },
    { conf:"BK-24022", g:"Novak J.",       vip:false, room:"502", type:"DLX",   eta:"16:30", nights:2, st:"no-show",     src:"Booking.com", rate:"BAR",  adults:1, rate_amt:9600 },
    { conf:"BK-24023", g:"Лебедев О.Ю.",   vip:false, room:"315", type:"STD",   eta:"17:00", nights:1, st:"confirmed",   src:"Прямой",      rate:"BAR",  adults:1, rate_amt:6200 },
    { conf:"BK-24024", g:"Морозова Е.И.",  vip:false, room:"118", type:"TWN",   eta:"17:30", nights:2, st:"checked-in", src:"Ostrovok",    rate:"PKG",  adults:2, rate_amt:7600 },
    { conf:"BK-24025", g:"Chen Li",        vip:false, room:"411", type:"DLX",   eta:"18:00", nights:4, st:"confirmed",   src:"Экспедия",    rate:"CORP", adults:2, rate_amt:9800 },
    { conf:"BK-24026", g:"Волков И.П.",    vip:false, room:"207", type:"STD",   eta:"18:00", nights:1, st:"checked-in", src:"Прямой",      rate:"BAR",  adults:1, rate_amt:6300 },
    { conf:"BK-24027", g:"Bauer W.",       vip:false, room:"609", type:"JR",    eta:"19:00", nights:3, st:"confirmed",   src:"Booking.com", rate:"PKG",  adults:2, rate_amt:12400 },
    { conf:"BK-24028", g:"Орлов М.А.",     vip:false, room:"214", type:"STD",   eta:"19:30", nights:1, st:"confirmed",   src:"Прямой",      rate:"BAR",  adults:1, rate_amt:6200 },
  ];

  // Due Out (departures today) — 9 bookings
  const DEPARTURES = [
    { conf:"BK-23987", g:"Белов А.Н.",     vip:false, room:"201", type:"STD",   etd:"11:00", st:"due-out",     balance:12400 },
    { conf:"BK-23991", g:"García L.",      vip:false, room:"308", type:"STD",   etd:"11:30", st:"checked-out", balance:0 },
    { conf:"BK-23994", g:"Кузнецова Т.В.", vip:false, room:"415", type:"DLX",   etd:"12:00", st:"checked-out", balance:0 },
    { conf:"BK-23995", g:"Müller S.",      vip:true,  room:"512", type:"SUITE", etd:"12:00", st:"due-out",     balance:8200, note:"late-CO" },
    { conf:"BK-23998", g:"Соколов П.Р.",   vip:false, room:"122", type:"TWN",   etd:"12:30", st:"checked-out", balance:0 },
    { conf:"BK-24001", g:"Ким Ю.Х.",       vip:false, room:"405", type:"DLX",   etd:"13:00", st:"due-out",     balance:3100, note:"late-CO" },
    { conf:"BK-24003", g:"Орлова Н.С.",    vip:false, room:"218", type:"STD",   etd:"13:30", st:"checked-out", balance:0 },
    { conf:"BK-24004", g:"Bauer W.",       vip:false, room:"609", type:"JR",    etd:"14:00", st:"checked-out", balance:0 },
    { conf:"BK-24005", g:"Иванов С.К.",    vip:false, room:"211", type:"STD",   etd:"14:00", st:"checked-out", balance:0 },
  ];

  // Alerts
  const ALERTS = [
    { sev:"high", ti:"OOO третий день: 302 — сантехника", sub:"Потеря дохода 3×6 200 ₽ = 18 600 ₽. Эскалировать инженеру.", ts:"2026-04-18 09:12" },
    { sev:"med",  ti:"VIP заезд в 15:00 — Иванов А.П. → 508", sub:"Подготовить welcome amenities, трансфер из Пулково в 14:20.", ts:"today 08:40" },
    { sev:"med",  ti:"Late check-out × 2: 214, 508 — уведомить HK", sub:"Выезд в 14:00 и 13:00 соответственно.", ts:"today 09:05" },
    { sev:"low",  ti:"Overbooking risk 22 апр: DBL −3", sub:"Рассмотреть upsell в Deluxe или перемещение на 23-е.", ts:"today 07:30" },
  ];

  // 14-day forecast for tape chart
  const DAYS = (function(){
    const start = new Date("2026-04-20T00:00:00");
    const arr = [];
    const names = ["пн","вт","ср","чт","пт","сб","вс"];
    for (let i=0; i<14; i++){
      const d = new Date(start); d.setDate(start.getDate()+i);
      arr.push({
        date: d.toISOString().slice(0,10),
        day: d.getDate(),
        mon: ["янв","фев","мар","апр","май","июн","июл","авг","сен","окт","ноя","дек"][d.getMonth()],
        dow: names[(d.getDay()+6)%7],
        weekend: d.getDay()===6 || d.getDay()===0,
        today: i===0,
      });
    }
    return arr;
  })();

  // Tape-chart rooms (subset for demo; 24 rooms across types)
  // bars: [{startDay, length, status, guest, conf}]
  const TAPE_ROOMS = [
    // STD
    { n:"118", type:"STD", hk:"clean",     bars:[{s:-1,l:3,st:"checked-in",g:"Морозова Е.И.",c:"BK-24024",vip:false},{s:4,l:2,st:"confirmed",g:"Лопатина",c:"BK-24032"}] },
    { n:"201", type:"STD", hk:"dirty",     bars:[{s:-3,l:1,st:"due-out",g:"Белов А.Н.",c:"BK-23987"},{s:2,l:4,st:"confirmed",g:"Jensen P.",c:"BK-24041"}] },
    { n:"207", type:"STD", hk:"clean",     bars:[{s:0,l:1,st:"checked-in",g:"Волков И.П.",c:"BK-24026"},{s:3,l:3,st:"confirmed",g:"Rossi M.",c:"BK-24055"}] },
    { n:"211", type:"STD", hk:"pickup",    bars:[{s:-2,l:0.5,st:"checked-out",g:"Иванов С.К.",c:"BK-24005"},{s:1,l:5,st:"confirmed",g:"Kowalski A.",c:"BK-24061"}] },
    { n:"214", type:"STD", hk:"clean",     bars:[{s:0,l:1,st:"confirmed",g:"Орлов М.А.",c:"BK-24028"},{s:2,l:3,st:"confirmed",g:"Novikov",c:"BK-24062"},{s:7,l:2,st:"confirmed",g:"Tanaka",c:"BK-24070"}] },
    { n:"218", type:"STD", hk:"inspected", bars:[{s:-1,l:1,st:"checked-out",g:"Орлова Н.С.",c:"BK-24003"},{s:3,l:4,st:"confirmed",g:"Ahmad S.",c:"BK-24063"}] },
    { n:"221", type:"STD", hk:"clean",     bars:[{s:0,l:3,st:"confirmed",g:"Смирнов Д.К.",c:"BK-24020"},{s:5,l:2,st:"confirmed",g:"García",c:"BK-24071"}] },
    { n:"302", type:"STD", hk:"ooo",       bars:[{s:-2,l:14,st:"ooo",g:"OOO — сантехника",c:"MAINT"}] },
    { n:"305", type:"STD", hk:"dirty",     bars:[{s:0,l:2,st:"confirmed",g:"Петров С.И.",c:"BK-24017"},{s:3,l:5,st:"confirmed",g:"Lindqvist",c:"BK-24072"}] },
    { n:"308", type:"STD", hk:"dirty",     bars:[{s:-4,l:1,st:"checked-out",g:"García L.",c:"BK-23991"},{s:1,l:4,st:"confirmed",g:"Dubois",c:"BK-24073"},{s:8,l:3,st:"cancelled",g:"Meier",c:"BK-24081"}] },
    { n:"315", type:"STD", hk:"clean",     bars:[{s:0,l:1,st:"confirmed",g:"Лебедев О.Ю.",c:"BK-24023"},{s:2,l:6,st:"confirmed",g:"Kowalski B.",c:"BK-24082"}] },
    // TWN
    { n:"122", type:"TWN", hk:"pickup",    bars:[{s:-3,l:1,st:"checked-out",g:"Соколов П.Р.",c:"BK-23998"},{s:2,l:3,st:"confirmed",g:"Yamada",c:"BK-24083"}] },
    { n:"225", type:"TWN", hk:"clean",     bars:[{s:-2,l:5,st:"checked-in",g:"Novikova",c:"BK-23978"},{s:6,l:4,st:"confirmed",g:"Schmidt",c:"BK-24084"}] },
    { n:"301", type:"TWN", hk:"dirty",     bars:[{s:-1,l:2,st:"checked-in",g:"Levin",c:"BK-23988"},{s:3,l:5,st:"confirmed",g:"O'Brien",c:"BK-24085"}] },
    // DLX
    { n:"405", type:"DLX", hk:"pickup",    bars:[{s:-2,l:1,st:"due-out",g:"Ким Ю.Х.",c:"BK-24001"},{s:2,l:4,st:"confirmed",g:"Белоусов",c:"BK-24086"}] },
    { n:"411", type:"DLX", hk:"clean",     bars:[{s:0,l:4,st:"confirmed",g:"Chen Li",c:"BK-24025"},{s:6,l:3,st:"confirmed",g:"Park",c:"BK-24087"}] },
    { n:"412", type:"DLX", hk:"inspected", bars:[{s:0,l:2,st:"checked-in",g:"Козлова М.В.",c:"BK-24019"},{s:4,l:5,st:"confirmed",g:"Эрдоган",c:"BK-24088"}] },
    { n:"415", type:"DLX", hk:"dirty",     bars:[{s:-3,l:1,st:"checked-out",g:"Кузнецова Т.В.",c:"BK-23994"},{s:2,l:6,st:"confirmed",g:"Henriksen",c:"BK-24089"}] },
    { n:"502", type:"DLX", hk:"clean",     bars:[{s:0,l:2,st:"no-show",g:"Novak J.",c:"BK-24022"},{s:3,l:3,st:"confirmed",g:"Романова",c:"BK-24090"}] },
    // JR
    { n:"609", type:"JR",  hk:"dirty",     bars:[{s:-3,l:1,st:"checked-out",g:"Bauer W.",c:"BK-24004"},{s:0,l:3,st:"confirmed",g:"Bauer W.",c:"BK-24027"},{s:5,l:4,st:"confirmed",g:"Zhang",c:"BK-24091"}] },
    { n:"610", type:"JR",  hk:"clean",     bars:[{s:0,l:2,st:"confirmed",g:"Fischer K.",c:"BK-24021"},{s:4,l:3,st:"confirmed",g:"Laurent",c:"BK-24092"}] },
    // SUITE
    { n:"508", type:"SUITE", hk:"inspected", bars:[{s:0,l:1,st:"confirmed",g:"Иванов А.П. VIP",c:"BK-24018",vip:true},{s:3,l:4,st:"confirmed",g:"Khan A. VIP",c:"BK-24093",vip:true}] },
    { n:"512", type:"SUITE", hk:"pickup",    bars:[{s:-4,l:1,st:"due-out",g:"Müller S.",c:"BK-23995",vip:true},{s:2,l:3,st:"confirmed",g:"Abramov VIP",c:"BK-24094",vip:true}] },
  ];

  // Bookings list (combines arrivals + departures + in-house sample)
  const BOOKINGS_EXTRA = [
    { conf:"BK-23978", g:"Novikova",      vip:false, room:"225", type:"TWN",   arr:"2026-04-18", dep:"2026-04-23", nights:5, st:"checked-in",  src:"Прямой",     rate:"BAR",  total:38000, balance:0 },
    { conf:"BK-23988", g:"Levin",         vip:false, room:"301", type:"TWN",   arr:"2026-04-19", dep:"2026-04-21", nights:2, st:"checked-in",  src:"Booking.com",rate:"BAR",  total:13800, balance:0 },
    { conf:"BK-24041", g:"Jensen P.",     vip:false, room:"201", type:"STD",   arr:"2026-04-22", dep:"2026-04-26", nights:4, st:"confirmed",   src:"Booking.com",rate:"BAR",  total:24800, balance:24800 },
    { conf:"BK-24055", g:"Rossi M.",      vip:false, room:"207", type:"STD",   arr:"2026-04-23", dep:"2026-04-26", nights:3, st:"confirmed",   src:"Expedia",    rate:"BAR",  total:18900, balance:0 },
    { conf:"BK-24061", g:"Kowalski A.",   vip:false, room:"211", type:"STD",   arr:"2026-04-21", dep:"2026-04-26", nights:5, st:"confirmed",   src:"Ostrovok",   rate:"CORP", total:31000, balance:31000 },
    { conf:"BK-24081", g:"Meier",         vip:false, room:"308", type:"STD",   arr:"2026-04-28", dep:"2026-05-01", nights:3, st:"cancelled",   src:"Booking.com",rate:"BAR",  total:0,     balance:0 },
    { conf:"BK-24093", g:"Khan A.",       vip:true,  room:"508", type:"SUITE", arr:"2026-04-23", dep:"2026-04-27", nights:4, st:"confirmed",   src:"Прямой",     rate:"BAR",  total:76000, balance:0 },
  ];

  function allBookings(){
    const arrs = ARRIVALS.map(x => ({...x, arr:"2026-04-20", dep:addDays("2026-04-20", x.nights), total:x.rate_amt*x.nights, balance:x.rate_amt*x.nights}));
    const deps = DEPARTURES.map(x => ({...x, arr:addDays("2026-04-20", -2), dep:"2026-04-20", nights:2, src:"Прямой", rate:"BAR", total:x.balance||14000, balance:x.balance}));
    return [...arrs, ...deps, ...BOOKINGS_EXTRA];
  }

  function addDays(d, n){
    const x = new Date(d); x.setDate(x.getDate()+n);
    return x.toISOString().slice(0,10);
  }

  // Profiles (guests)
  const PROFILES = [
    { id:"GP-0012", name:"Иванов Александр Петрович", country:"RU", email:"ivanov@example.ru", phone:"+7 921 555 1204", stays:14, ltv:892000, vip:true,  pref:"Предпочитает suite, аллергия на перья, late check-out", last:"2026-03-02", company:"Газпром" },
    { id:"GP-0189", name:"Müller Stefan",               country:"DE", email:"smueller@ex.de",    phone:"+49 170 234 5566", stays:6,  ltv:412000, vip:true,  pref:"Тихий номер, non-smoking, двуспальная кровать", last:"2026-04-12", company:"BMW" },
    { id:"GP-0321", name:"Chen Li",                     country:"CN", email:"chen.li@ex.cn",     phone:"+86 138 0013 8000", stays:3, ltv:98000,  vip:false, pref:"English speaker, vegetarian", last:"2026-02-18", company:"Alibaba" },
    { id:"GP-0402", name:"Петров Сергей Иванович",      country:"RU", email:"s.petrov@ex.ru",    phone:"+7 903 444 0988", stays:22, ltv:540000, vip:false, pref:"Корпоратив BAR, ужин 19:00", last:"2026-04-01", company:"СберБанк" },
    { id:"GP-0513", name:"García Luis",                 country:"ES", email:"lgarcia@ex.es",     phone:"+34 600 12 34 56", stays:1,  ltv:18000,  vip:false, pref:"—", last:"2026-04-17", company:"—" },
    { id:"GP-0601", name:"Fischer Klaus",               country:"DE", email:"kfischer@ex.de",    phone:"+49 151 998 7765", stays:4,  ltv:186000, vip:false, pref:"Завтрак в номер, поздний заезд", last:"2026-01-22", company:"Siemens" },
  ];

  // House status snapshot for HK board
  const HK_ROOMS = [
    // floor → list of rooms for kanban/grid
    { n:"101", hk:"dirty",     type:"STD",   guest:"Белов А.Н.",   status:"due-out",   pr:"hi" },
    { n:"102", hk:"dirty",     type:"STD",   guest:"-",            status:"vacant",    pr:"lo" },
    { n:"118", hk:"clean",     type:"TWN",   guest:"Морозова Е.И.",status:"stayover",  pr:"lo" },
    { n:"122", hk:"pickup",    type:"TWN",   guest:"Соколов П.Р.", status:"checked-out",pr:"hi"},
    { n:"201", hk:"dirty",     type:"STD",   guest:"Белов А.Н.",   status:"due-out",   pr:"hi" },
    { n:"207", hk:"clean",     type:"STD",   guest:"Волков И.П.",  status:"stayover",  pr:"lo" },
    { n:"211", hk:"pickup",    type:"STD",   guest:"-",            status:"checked-out",pr:"hi"},
    { n:"218", hk:"inspected", type:"STD",   guest:"-",            status:"vacant",    pr:"lo" },
    { n:"221", hk:"clean",     type:"STD",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"302", hk:"ooo",       type:"STD",   guest:"-",            status:"ooo",       pr:"lo" },
    { n:"305", hk:"dirty",     type:"STD",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"308", hk:"dirty",     type:"STD",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"315", hk:"clean",     type:"STD",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"405", hk:"pickup",    type:"DLX",   guest:"Ким Ю.Х.",     status:"due-out",   pr:"hi" },
    { n:"411", hk:"clean",     type:"DLX",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"412", hk:"inspected", type:"DLX",   guest:"Козлова М.В.", status:"stayover",  pr:"lo" },
    { n:"415", hk:"dirty",     type:"DLX",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"502", hk:"clean",     type:"DLX",   guest:"-",            status:"vacant",    pr:"hi" },
    { n:"508", hk:"inspected", type:"SUITE", guest:"-",            status:"arrival",   pr:"vip"},
    { n:"512", hk:"pickup",    type:"SUITE", guest:"Müller S.",    status:"due-out",   pr:"vip"},
    { n:"609", hk:"dirty",     type:"JR",    guest:"-",            status:"vacant",    pr:"hi" },
    { n:"610", hk:"clean",     type:"JR",    guest:"-",            status:"arrival",   pr:"hi" },
  ];

  // Folio sample for booking detail
  const FOLIO_SAMPLE = {
    booking: "BK-24025",
    guest: "Chen Li",
    window_A: {
      label: "Window A — Room & Taxes",
      payer: "Гость",
      lines: [
        { date:"2026-04-20", desc:"Room charge — DLX 411",            qty:1, amt:9800 },
        { date:"2026-04-20", desc:"City tax",                         qty:1, amt:200 },
        { date:"2026-04-21", desc:"Room charge — DLX 411",            qty:1, amt:9800 },
        { date:"2026-04-21", desc:"City tax",                         qty:1, amt:200 },
        { date:"2026-04-21", desc:"Мини-бар — Perrier ×2",            qty:2, amt:600 },
        { date:"2026-04-22", desc:"Room charge — DLX 411",            qty:1, amt:9800 },
        { date:"2026-04-22", desc:"City tax",                         qty:1, amt:200 },
      ],
      total: 30600, paid: 0, balance: 30600
    },
    window_B: {
      label: "Window B — Meals (корп. счёт)",
      payer: "Alibaba Group",
      lines: [
        { date:"2026-04-20", desc:"Завтрак — шведский стол",           qty:2, amt:2400 },
        { date:"2026-04-21", desc:"Завтрак — шведский стол",           qty:2, amt:2400 },
      ],
      total: 4800, paid: 4800, balance: 0
    }
  };

  return { BIZ_DATE, HOTEL, ROOM_TYPES, HK, KPI, ARRIVALS, DEPARTURES, ALERTS, DAYS, TAPE_ROOMS, BOOKINGS_EXTRA, allBookings, PROFILES, HK_ROOMS, FOLIO_SAMPLE, addDays };
})();
