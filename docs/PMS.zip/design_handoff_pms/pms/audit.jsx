// ===== NIGHT AUDIT — wizard/stepper =====
function AuditScreen(){
  const [step, setStep] = React.useState(2); // currently on step 3 (idx 2)
  const steps = [
    { k:"verify",     ti:"Проверка данных",   desc:"Сверка заездов, выездов, no-show" },
    { k:"post",       ti:"Начисления дня",    desc:"Room charge, city tax, пакеты" },
    { k:"reconcile",  ti:"Сверка касс",       desc:"Отчёты по сменам" },
    { k:"reports",    ti:"Отчёты",            desc:"Дневной, налоговый, статистика" },
    { k:"rollover",   ti:"Смена даты",        desc:"20 апр → 21 апр" },
  ];

  const checks = [
    { ti:"Заезды без check-in", n:1, ex:"Novak J. (502) — no-show", sev:"warn", done:false },
    { ti:"Выезды без check-out", n:3, ex:"Белов (201), Müller (512), Ким (405)", sev:"warn", done:false },
    { ti:"Незакрытые балансы", n:1, ex:"BK-23987 Белов А.Н. — 12 400 ₽", sev:"warn", done:false },
    { ti:"OOO > 2 дней", n:1, ex:"302 — сантехника, 3-й день", sev:"info", done:true },
    { ti:"Открытые кассовые смены", n:0, ex:"—", sev:"ok", done:true },
  ];

  return (
    <Shell current="audit">
      <div className="page-head">
        <h1 className="page-title">Ночной аудит</h1>
        <span className="page-sub">Операционный день · 20 апр 2026 · инициировано 22:14 · оператор А. Кузнецова</span>
        <div className="actions">
          <button className="btn sm">Приостановить</button>
          <button className="btn sm danger">Отменить аудит</button>
          <button className="btn sm primary">Продолжить <Icon name="chevRight" size={12}/></button>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div className="wz-steps">
            {steps.map((s,i) => (
              <div key={s.k} className={`s ${i<step?"done":""} ${i===step?"active":""}`}>
                <div className="n">{i<step ? <Icon name="check" size={12}/> : i+1}</div>
                <div>
                  <div>{s.ti}</div>
                  <div style={{fontSize:10.5,color:"var(--muted)",fontWeight:400}}>{s.desc}</div>
                </div>
              </div>
            ))}
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:18}}>
            <div>
              <h2 style={{fontSize:15,fontWeight:600,margin:"0 0 4px"}}>Шаг 3 · Сверка касс</h2>
              <div style={{color:"var(--muted)",fontSize:12,marginBottom:14}}>Проверьте закрытие всех кассовых смен и совпадение Z-отчётов</div>

              <table className="t" style={{border:"1px solid var(--border)",borderRadius:8,overflow:"hidden"}}>
                <thead><tr>
                  <th>Касса</th><th>Кассир</th><th>Открыта</th><th>Закрыта</th>
                  <th className="r">По PMS</th><th className="r">По Z-отчёту</th>
                  <th className="r">Δ</th><th>Статус</th>
                </tr></thead>
                <tbody>
                  <tr>
                    <td><strong>Ресепшн</strong></td>
                    <td>А. Кузнецова</td>
                    <td className="tnum">08:00</td>
                    <td className="tnum">20:05</td>
                    <td className="r tnum">184 200 ₽</td>
                    <td className="r tnum">184 200 ₽</td>
                    <td className="r tnum" style={{color:"var(--checked-in)"}}>0</td>
                    <td><span className="badge checked-in"><span className="dot"/>Совпадает</span></td>
                  </tr>
                  <tr>
                    <td><strong>Ресепшн</strong></td>
                    <td>И. Волков</td>
                    <td className="tnum">20:00</td>
                    <td className="tnum">—</td>
                    <td className="r tnum">46 400 ₽</td>
                    <td className="r tnum">—</td>
                    <td className="r tnum" style={{color:"var(--muted)"}}>—</td>
                    <td><span className="badge no-show"><span className="dot"/>Открыта</span></td>
                  </tr>
                  <tr>
                    <td><strong>Ресторан</strong></td>
                    <td>Е. Морозов</td>
                    <td className="tnum">07:00</td>
                    <td className="tnum">23:30</td>
                    <td className="r tnum">89 600 ₽</td>
                    <td className="r tnum">89 400 ₽</td>
                    <td className="r tnum" style={{color:"var(--cancelled)"}}>−200</td>
                    <td><span className="badge cancelled"><span className="dot"/>Расхождение</span></td>
                  </tr>
                  <tr>
                    <td><strong>Бар</strong></td>
                    <td>Н. Смирнова</td>
                    <td className="tnum">18:00</td>
                    <td className="tnum">02:00</td>
                    <td className="r tnum">34 100 ₽</td>
                    <td className="r tnum">34 100 ₽</td>
                    <td className="r tnum" style={{color:"var(--checked-in)"}}>0</td>
                    <td><span className="badge checked-in"><span className="dot"/>Совпадает</span></td>
                  </tr>
                </tbody>
              </table>

              <div style={{marginTop:14,padding:"10px 12px",background:"var(--cancelled-bg)",border:"1px solid var(--cancelled)",borderRadius:6,fontSize:12.5,color:"var(--cancelled-fg)",display:"flex",alignItems:"flex-start",gap:8}}>
                <Icon name="alert" size={14}/>
                <div>
                  <strong>Расхождение в кассе «Ресторан»:</strong> −200 ₽.
                  Требуется объяснение кассира до продолжения аудита.
                </div>
              </div>
            </div>

            <div className="col">
              <div className="card">
                <div className="card-head"><div className="card-title">Чек-лист дня</div></div>
                <div className="card-body flush">
                  {checks.map((c,i)=>(
                    <div key={i} style={{display:"flex",gap:8,padding:"8px 12px",borderBottom:"1px solid var(--border)",fontSize:12,alignItems:"flex-start"}}>
                      <div style={{width:16,height:16,borderRadius:4,background:c.done?"var(--checked-in)":c.sev==="warn"?"var(--no-show)":"var(--accent-soft)",color:c.done?"#fff":c.sev==="warn"?"#fff":"var(--accent)",display:"grid",placeItems:"center",flexShrink:0,marginTop:1}}>
                        {c.done ? <Icon name="check" size={10}/> : c.n}
                      </div>
                      <div>
                        <div style={{fontWeight:500}}>{c.ti}</div>
                        <div style={{color:"var(--muted)",fontSize:11}}>{c.ex}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="card">
                <div className="card-head"><div className="card-title">Предварительные итоги</div></div>
                <div className="card-body" style={{fontSize:12}}>
                  <div className="leg"><span className="lab">Выручка, номерной фонд</span><strong>873 200 ₽</strong></div>
                  <div className="leg"><span className="lab">F&B</span><strong>127 900 ₽</strong></div>
                  <div className="leg"><span className="lab">Доп. услуги</span><strong>42 600 ₽</strong></div>
                  <div style={{borderTop:"1px solid var(--border)",margin:"8px 0"}}/>
                  <div className="leg"><span className="lab" style={{color:"var(--fg)",fontWeight:600}}>Итого</span><strong style={{fontSize:14}}>1 043 700 ₽</strong></div>
                  <div className="leg"><span className="lab">Платежи принято</span><strong style={{color:"var(--checked-in)"}}>974 200 ₽</strong></div>
                  <div className="leg"><span className="lab">В дебиторке</span><strong style={{color:"var(--cancelled)"}}>69 500 ₽</strong></div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<AuditScreen/>);
