// ===== PROFILES =====
const PD = window.PMS_DATA;
function ProfilesScreen(){
  return (
    <Shell current="profiles">
      <div className="page-head">
        <h1 className="page-title">Профили гостей</h1>
        <span className="page-sub">{PD.PROFILES.length} показано · 1 847 всего в базе</span>
        <div className="actions">
          <button className="btn sm"><Icon name="download" size={12}/> Экспорт</button>
          <button className="btn sm primary"><Icon name="plus" size={12}/> Новый профиль</button>
        </div>
      </div>

      <div className="filterbar">
        <div style={{display:"flex",alignItems:"center",gap:6,border:"1px solid var(--border)",borderRadius:6,padding:"4px 10px",background:"var(--bg-subtle)",minWidth:280}}>
          <Icon name="search" size={13} style={{color:"var(--muted)"}}/>
          <input placeholder="Имя, email, телефон, ID…" style={{border:"none",outline:"none",background:"transparent",color:"var(--fg)",fontSize:12,fontFamily:"inherit",flex:1}}/>
        </div>
        <div className="fld on">+ VIP</div>
        <div className="fld">+ С компанией</div>
        <div className="fld"><span className="key">Страна:</span> Все</div>
        <div className="fld"><span className="key">Проживаний:</span> ≥ 3</div>
      </div>

      <div className="card" style={{padding:0}}>
        <table className="t">
          <thead><tr>
            <th>ID</th><th>Гость</th><th>Страна</th><th>Компания</th><th>Контакты</th>
            <th className="r">Проживаний</th><th className="r">LTV</th><th>Последний</th><th></th>
          </tr></thead>
          <tbody>
            {PD.PROFILES.map(p=>(
              <tr key={p.id} style={{cursor:"pointer"}}>
                <td className="conf">{p.id}</td>
                <td>
                  <div className="guest">
                    <span className="av">{p.name.split(" ").map(x=>x[0]).slice(0,2).join("")}</span>
                    <span>
                      <span className="nm">{p.name}</span>
                      {p.vip && <span className="badge vip" style={{marginLeft:6}}>VIP</span>}
                      <div className="sub">{p.pref}</div>
                    </span>
                  </div>
                </td>
                <td><span className="chip">{p.country}</span></td>
                <td>{p.company}</td>
                <td style={{fontSize:11.5,color:"var(--muted)"}}>
                  <div>{p.email}</div>
                  <div className="tnum">{p.phone}</div>
                </td>
                <td className="r tnum">{p.stays}</td>
                <td className="r tnum" style={{fontWeight:600}}>{p.ltv.toLocaleString("ru-RU")} ₽</td>
                <td className="tnum" style={{color:"var(--muted)"}}>{p.last}</td>
                <td className="r"><Icon name="more" size={13} style={{color:"var(--muted)"}}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Shell>
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(<ProfilesScreen/>);
