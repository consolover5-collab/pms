// ===== NEW BOOKING WIZARD =====
function NewBookingScreen(){
  const [step, setStep] = React.useState(1);
  const steps = [
    {k:"dates", ti:"Даты и номер"},
    {k:"guest", ti:"Гость"},
    {k:"rate",  ti:"Тариф и услуги"},
    {k:"pay",   ti:"Оплата"},
    {k:"conf",  ti:"Подтверждение"},
  ];

  const avail = [
    { type:"STD",   name:"Standard",      avail:12, rate:6200 },
    { type:"TWN",   name:"Twin",          avail:8,  rate:7600 },
    { type:"DLX",   name:"Deluxe",        avail:4,  rate:9800 },
    { type:"JR",    name:"Junior Suite",  avail:6,  rate:11200, best:true },
    { type:"SUITE", name:"Suite",         avail:2,  rate:18900 },
  ];

  return (
    <Shell current="new">
      <div className="page-head">
        <h1 className="page-title">Новая бронь</h1>
        <span className="page-sub">Шаг {step+1} из {steps.length} · черновик сохраняется автоматически</span>
        <div className="actions">
          <button className="btn sm">Сохранить черновик</button>
          <button className="btn sm danger">Отменить</button>
        </div>
      </div>

      <div className="card">
        <div className="card-body">
          <div className="wz-steps">
            {steps.map((s,i)=>(
              <div key={s.k} className={`s ${i<step?"done":""} ${i===step?"active":""}`}>
                <div className="n">{i<step?<Icon name="check" size={12}/>:i+1}</div>
                <div>{s.ti}</div>
              </div>
            ))}
          </div>

          <div style={{display:"grid",gridTemplateColumns:"1fr 340px",gap:18}}>
            <div>
              <h2 style={{fontSize:15,fontWeight:600,margin:"0 0 14px"}}>Шаг 2 · Выбор номера</h2>

              <div className="grid g4" style={{marginBottom:16}}>
                <div className="field"><div className="lab">Заезд</div><input className="input" defaultValue="20.04.2026"/></div>
                <div className="field"><div className="lab">Выезд</div><input className="input" defaultValue="23.04.2026"/></div>
                <div className="field"><div className="lab">Взрослые</div><input className="input" defaultValue="2"/></div>
                <div className="field"><div className="lab">Дети</div><input className="input" defaultValue="0"/></div>
              </div>

              <div style={{fontSize:12,color:"var(--muted)",marginBottom:8}}>Доступные категории на 3 ночи:</div>
              <div className="col" style={{gap:8}}>
                {avail.map(a=>(
                  <div key={a.type} className="card" style={{display:"flex",alignItems:"center",gap:14,padding:12, borderColor: a.best?"var(--accent)":"var(--border)"}}>
                    <div style={{width:60,height:60,background:"var(--surface-2)",borderRadius:6,display:"grid",placeItems:"center",color:"var(--muted)"}}>
                      <Icon name="bed" size={24}/>
                    </div>
                    <div style={{flex:1}}>
                      <div style={{display:"flex",alignItems:"center",gap:8}}>
                        <strong>{a.name}</strong>
                        <span className="chip">{a.type}</span>
                        {a.best && <span className="badge confirmed">Рекомендуется</span>}
                      </div>
                      <div style={{fontSize:12,color:"var(--muted)",marginTop:2}}>
                        {a.avail} номеров свободно · до 2 гостей · мини-бар · wi-fi
                      </div>
                    </div>
                    <div style={{textAlign:"right",minWidth:120}}>
                      <div style={{fontSize:18,fontWeight:700,fontVariantNumeric:"tabular-nums"}}>{a.rate.toLocaleString("ru-RU")} ₽</div>
                      <div style={{fontSize:11,color:"var(--muted)"}}>BAR за ночь</div>
                    </div>
                    <button className={`btn ${a.best?"primary":""}`}>Выбрать</button>
                  </div>
                ))}
              </div>
            </div>

            <div className="col">
              <div className="card">
                <div className="card-head"><div className="card-title">Сводка брони</div></div>
                <div className="card-body" style={{fontSize:12}}>
                  <div className="leg"><span className="lab">Заезд</span><strong>20 апр 2026</strong></div>
                  <div className="leg"><span className="lab">Выезд</span><strong>23 апр 2026</strong></div>
                  <div className="leg"><span className="lab">Ночей</span><strong>3</strong></div>
                  <div className="leg"><span className="lab">Гостей</span><strong>2 взр</strong></div>
                  <div style={{borderTop:"1px solid var(--border)",margin:"8px 0"}}/>
                  <div style={{color:"var(--muted)",fontSize:11,textAlign:"center",padding:"10px 0"}}>Выберите номер для расчёта</div>
                </div>
              </div>

              <div className="card">
                <div className="card-head"><div className="card-title">Подсказки</div></div>
                <div className="card-body" style={{fontSize:12,color:"var(--muted)",lineHeight:1.6}}>
                  <div style={{display:"flex",gap:8,alignItems:"flex-start"}}>
                    <Icon name="info" size={13} style={{color:"var(--accent)",flexShrink:0,marginTop:1}}/>
                    <div>22 апр — overbooking по DBL. Рекомендуем upsell в JR/DLX.</div>
                  </div>
                  <div style={{display:"flex",gap:8,alignItems:"flex-start",marginTop:8}}>
                    <Icon name="sparkles" size={13} style={{color:"var(--accent)",flexShrink:0,marginTop:1}}/>
                    <div>CORP-тариф −15% для контрактных компаний</div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div style={{display:"flex",justifyContent:"space-between",paddingTop:14,borderTop:"1px solid var(--border)",marginTop:14}}>
            <button className="btn" onClick={()=>setStep(s=>Math.max(0,s-1))}><Icon name="chevLeft" size={12}/> Назад</button>
            <button className="btn primary" onClick={()=>setStep(s=>Math.min(4,s+1))}>Далее <Icon name="chevRight" size={12}/></button>
          </div>
        </div>
      </div>
    </Shell>
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(<NewBookingScreen/>);
