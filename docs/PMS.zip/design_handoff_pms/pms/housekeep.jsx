// ===== HOUSEKEEPING BOARD =====
const HD = window.PMS_DATA;

function HKScreen(){
  const cols = [
    { k:"dirty",     ti:"Dirty",     desc:"Требует уборки",        cls:"hk-dirty" },
    { k:"pickup",    ti:"Pickup",    desc:"Частичная уборка",      cls:"hk-pickup" },
    { k:"clean",     ti:"Clean",     desc:"Убран, ждёт проверки",  cls:"hk-clean" },
    { k:"inspected", ti:"Inspected", desc:"Готов к заселению",     cls:"hk-inspected" },
    { k:"ooo",       ti:"OOO",       desc:"Out-of-order",          cls:"hk-ooo" },
    { k:"oos",       ti:"OOS",       desc:"Out-of-service",        cls:"hk-oos" },
  ];
  const by = (k) => HD.HK_ROOMS.filter(r=>r.hk===k);

  return (
    <Shell current="housekeep">
      <div className="page-head">
        <h1 className="page-title">Housekeeping</h1>
        <span className="page-sub">Борд на 20 апр · смена горничных 08:00–16:00 · 6 горничных</span>
        <div className="actions">
          <div className="ptabs">
            <div className="pt on">Борд</div>
            <div className="pt">По этажам</div>
            <div className="pt">По горничным</div>
            <div className="pt">Задачи</div>
          </div>
          <button className="btn sm"><Icon name="print" size={12}/> Листы смены</button>
          <button className="btn sm primary"><Icon name="plus" size={12}/> Задача</button>
        </div>
      </div>

      <div className="grid g6">
        {cols.map(c => (
          <div key={c.k} className="kpi" style={{minHeight:60}}>
            <div className="lab" style={{display:"flex",alignItems:"center",gap:6}}>
              <span style={{width:8,height:8,borderRadius:"50%",background:`var(--${c.cls})`}}/>{c.ti}
            </div>
            <div className="val" style={{fontSize:20}}>{HD.HK[c.k]}</div>
            <div className="foot" style={{fontSize:10.5}}>{c.desc}</div>
          </div>
        ))}
      </div>

      <div className="kanban">
        {cols.map(c => {
          const rooms = by(c.k);
          return (
            <div className="kcol" key={c.k}>
              <h4><span style={{width:8,height:8,borderRadius:"50%",background:`var(--${c.cls})`}}/>{c.ti}<span className="n">{rooms.length}</span></h4>
              {rooms.map(r=>(
                <div className="kcard" key={r.n}>
                  <div style={{display:"flex",alignItems:"center",gap:6}}>
                    <span className="rno">{r.n}</span>
                    <span className="tp">{r.type}</span>
                    {r.pr==="vip" && <span className="badge vip" style={{marginLeft:"auto"}}>VIP</span>}
                    {r.pr==="hi" && <span style={{marginLeft:"auto",color:"var(--no-show)",fontSize:10.5,fontWeight:600}}>● Срочно</span>}
                  </div>
                  {r.guest!=="-" && <div style={{fontSize:11,color:"var(--muted)"}}>{r.guest}</div>}
                  <div className="tags">
                    {r.status==="due-out" && <span className="badge no-show" style={{fontSize:10}}>к выезду</span>}
                    {r.status==="arrival" && <span className="badge confirmed" style={{fontSize:10}}>заезд</span>}
                    {r.status==="checked-out" && <span className="badge checked-out" style={{fontSize:10}}>выехал</span>}
                    {r.status==="stayover" && <span className="badge" style={{fontSize:10,background:"var(--surface-2)",color:"var(--muted)"}}>stayover</span>}
                    {r.status==="ooo" && <span className="badge hk-ooo" style={{fontSize:10}}>сантехника</span>}
                  </div>
                </div>
              ))}
              {rooms.length===0 && <div style={{fontSize:11,color:"var(--muted-2)",textAlign:"center",padding:10}}>—</div>}
            </div>
          );
        })}
      </div>

      <div className="card">
        <div className="card-head">
          <div className="card-title">Назначения смены</div>
          <button className="btn xs ghost">Распределить автоматически</button>
        </div>
        <div className="card-body flush">
          <table className="t">
            <thead><tr>
              <th>Горничная</th>
              <th>Этаж</th>
              <th className="r">Номеров</th>
              <th className="r">Выполнено</th>
              <th>Прогресс</th>
              <th>Статус</th>
            </tr></thead>
            <tbody>
              {[
                {n:"Марина П.", fl:"1", tot:18, done:12, st:"active"},
                {n:"Ольга С.",  fl:"2", tot:20, done:14, st:"active"},
                {n:"Галина К.", fl:"3", tot:16, done:16, st:"done"},
                {n:"Анна Р.",   fl:"4", tot:22, done:8,  st:"active"},
                {n:"Света М.",  fl:"5", tot:14, done:5,  st:"active"},
                {n:"Людмила В.",fl:"6", tot:10, done:3,  st:"active"},
              ].map(r=>(
                <tr key={r.n}>
                  <td><div className="guest"><span className="av">{r.n.split(" ").map(x=>x[0]).join("")}</span><span className="nm">{r.n}</span></div></td>
                  <td className="tnum">{r.fl}</td>
                  <td className="r tnum">{r.tot}</td>
                  <td className="r tnum">{r.done}</td>
                  <td style={{width:220}}>
                    <div style={{height:6,background:"var(--surface-2)",borderRadius:3,overflow:"hidden"}}>
                      <div style={{height:"100%",width:`${r.done/r.tot*100}%`,background:r.st==="done"?"var(--checked-in)":"var(--accent)"}}/>
                    </div>
                  </td>
                  <td>{r.st==="done"?<span className="badge checked-in"><span className="dot"/>Готово</span>:<span className="badge confirmed"><span className="dot"/>В работе</span>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </Shell>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<HKScreen/>);
