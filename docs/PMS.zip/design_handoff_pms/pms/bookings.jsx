// ===== BOOKINGS LIST =====
const BD = window.PMS_DATA;
const fmt2 = (n) => n.toLocaleString("ru-RU");

function BookingsScreen(){
  const [tab, setTab] = React.useState("all");
  const [q, setQ] = React.useState("");
  const all = BD.allBookings();
  const counts = {
    all: all.length,
    confirmed: all.filter(b=>b.st==="confirmed").length,
    "checked-in": all.filter(b=>b.st==="checked-in").length,
    "checked-out": all.filter(b=>b.st==="checked-out").length,
    cancelled: all.filter(b=>b.st==="cancelled").length,
    "no-show": all.filter(b=>b.st==="no-show").length,
  };
  const filtered = all.filter(b => (tab==="all"||b.st===tab) && (!q || b.g.toLowerCase().includes(q.toLowerCase()) || b.conf.toLowerCase().includes(q.toLowerCase()) || b.room.includes(q)));

  const stLabel = {confirmed:"Подтверждена","checked-in":"Заехал","checked-out":"Выехал",cancelled:"Отменена","no-show":"No-show","due-out":"К выезду"};

  return (
    <Shell current="bookings">
      <div className="page-head">
        <h1 className="page-title">Брони</h1>
        <span className="page-sub">{filtered.length} из {all.length} записей</span>
        <div className="actions">
          <button className="btn sm"><Icon name="download" size={12}/> Экспорт</button>
          <button className="btn sm primary" onClick={()=>location.href="new.html"}><Icon name="plus" size={12}/> Новая бронь</button>
        </div>
      </div>

      <div className="tabs-bar">
        {[
          {id:"all",l:"Все"},
          {id:"confirmed",l:"Подтверждённые"},
          {id:"checked-in",l:"В отеле"},
          {id:"checked-out",l:"Выехали"},
          {id:"no-show",l:"No-show"},
          {id:"cancelled",l:"Отменённые"},
        ].map(t => (
          <div key={t.id} className={`tb ${tab===t.id?"on":""}`} onClick={()=>setTab(t.id)}>
            {t.l} <span className="count">{counts[t.id]||0}</span>
          </div>
        ))}
      </div>

      <div className="filterbar">
        <div style={{display:"flex",alignItems:"center",gap:6,border:"1px solid var(--border)",borderRadius:6,padding:"4px 10px",background:"var(--bg-subtle)",minWidth:280}}>
          <Icon name="search" size={13} style={{color:"var(--muted)"}}/>
          <input placeholder="Гость, № брони, номер комнаты…" value={q} onChange={e=>setQ(e.target.value)} style={{border:"none",outline:"none",background:"transparent",color:"var(--fg)",fontSize:12,fontFamily:"inherit",flex:1}}/>
        </div>
        <div className="fld"><span className="key">Даты:</span> 15 апр – 30 апр</div>
        <div className="fld"><span className="key">Тип:</span> Все</div>
        <div className="fld"><span className="key">Источник:</span> Все</div>
        <div className="fld on">+ VIP</div>
        <div className="fld">+ С балансом</div>
        <button className="btn xs ghost" style={{marginLeft:"auto"}}><Icon name="filter" size={11}/> Сохранить вид</button>
      </div>

      <div className="card" style={{padding:0}}>
        <table className="t">
          <thead><tr>
            <th style={{width:30}}><input type="checkbox"/></th>
            <th>№ брони</th>
            <th>Гость</th>
            <th>Номер</th>
            <th>Заезд</th>
            <th>Выезд</th>
            <th className="r">Ноч.</th>
            <th>Источник</th>
            <th>Тариф</th>
            <th>Статус</th>
            <th className="r">Сумма</th>
            <th className="r">Баланс</th>
            <th></th>
          </tr></thead>
          <tbody>
            {filtered.map(b=>(
              <tr key={b.conf} onClick={()=>location.href="booking-detail.html"} style={{cursor:"pointer"}}>
                <td><input type="checkbox" onClick={e=>e.stopPropagation()}/></td>
                <td className="conf">{b.conf}</td>
                <td>
                  <div className="guest">
                    <span className="av">{b.g.split(" ").map(x=>x[0]).slice(0,2).join("")}</span>
                    <span className="nm">{b.g}</span>
                    {b.vip && <span className="badge vip">VIP</span>}
                  </div>
                </td>
                <td className="tnum">{b.room} <span style={{color:"var(--muted)",fontSize:11}}>· {b.type}</span></td>
                <td className="tnum">{b.arr}</td>
                <td className="tnum">{b.dep}</td>
                <td className="r tnum">{b.nights}</td>
                <td style={{color:"var(--muted)"}}>{b.src}</td>
                <td><span className="chip">{b.rate}</span></td>
                <td><span className={`badge ${b.st==="due-out"?"no-show":b.st}`}><span className="dot"/>{stLabel[b.st]||b.st}</span></td>
                <td className="r tnum">{fmt2(b.total||0)} ₽</td>
                <td className="r tnum" style={{color: b.balance>0?"var(--cancelled)":"var(--muted)", fontWeight: b.balance>0?600:400}}>
                  {b.balance>0 ? `${fmt2(b.balance)} ₽` : "—"}
                </td>
                <td className="r"><Icon name="more" size={14} style={{color:"var(--muted)"}}/></td>
              </tr>
            ))}
          </tbody>
        </table>
        {filtered.length===0 && <div className="empty">Нет бронирований по текущим фильтрам</div>}
      </div>
    </Shell>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<BookingsScreen/>);
