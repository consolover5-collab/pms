// ===== DASHBOARD (Command Center) =====
const D = window.PMS_DATA;
const fmt = (n) => n.toLocaleString("ru-RU");
const money = (n) => `${fmt(n)} ₽`;

function KpiRow(){
  const k = D.KPI;
  return (
    <div className="grid g4">
      <div className="kpi accent">
        <div className="lab"><Icon name="bed" size={13}/> Загрузка</div>
        <div className="val">{k.occupancy}<span className="of">%</span></div>
        <div className="foot">
          <span>{k.rooms_sold} из {D.HOTEL.rooms} номеров</span>
          <span className="trend up"><Icon name="arrowUp" size={11}/> +{k.occ_delta}</span>
        </div>
      </div>
      <div className="kpi">
        <div className="lab"><Icon name="sparkles" size={13}/> ADR</div>
        <div className="val">{fmt(k.adr)}<span className="of"> ₽</span></div>
        <div className="foot">
          <span>средний тариф</span>
          <span className="trend up"><Icon name="arrowUp" size={11}/> +{k.adr_delta}%</span>
        </div>
      </div>
      <div className="kpi">
        <div className="lab"><Icon name="star" size={13}/> RevPAR</div>
        <div className="val">{fmt(k.revpar)}<span className="of"> ₽</span></div>
        <div className="foot">
          <span>vs. прошлая нд.</span>
          <span className="trend up"><Icon name="arrowUp" size={11}/> +{k.revpar_delta}%</span>
        </div>
      </div>
      <div className="kpi">
        <div className="lab"><Icon name="users" size={13}/> Гостей в отеле</div>
        <div className="val">{k.guests}</div>
        <div className="foot">
          <span>2.08 гостя / номер</span>
          <span>{k.arrivals} заезд · {k.departures} выезд</span>
        </div>
      </div>
    </div>
  );
}

function OccupancyCard(){
  const total = D.HOTEL.rooms;
  const occ = D.KPI.rooms_sold;
  const vac = total - occ - D.KPI.rooms_ooo - D.KPI.rooms_oos;
  const occPct = Math.round(occ/total*100);
  const vacPct = Math.round(vac/total*100);
  return (
    <div className="card" style={{gridColumn:"span 2"}}>
      <div className="card-head">
        <div className="card-title">Статус номерного фонда <span className="count">· на 09:00</span></div>
        <div className="ptabs">
          <div className="pt on">Сегодня</div>
          <div className="pt">Завтра</div>
          <div className="pt">7 дней</div>
        </div>
      </div>
      <div className="card-body" style={{display:"flex", gap:24, alignItems:"center"}}>
        <div className="donut" style={{"--occ":occPct, "--vac":vacPct, "--ooo":2, "--oos":1}}>
          <div className="mid">{occPct}%<small>occupancy</small></div>
        </div>
        <div style={{flex:1}}>
          <div className="leg"><span className="lab" style={{color:"var(--occ-occupied)"}}><span className="sw"/> Занято</span><strong>{occ} / {total}</strong></div>
          <div className="leg"><span className="lab" style={{color:"var(--muted-2)"}}><span className="sw"/> Свободно</span><strong>{vac}</strong></div>
          <div className="leg"><span className="lab" style={{color:"var(--hk-ooo)"}}><span className="sw"/> Out-of-order</span><strong>{D.KPI.rooms_ooo}</strong></div>
          <div className="leg"><span className="lab" style={{color:"var(--hk-oos)"}}><span className="sw"/> Out-of-service</span><strong>{D.KPI.rooms_oos}</strong></div>
          <div style={{borderTop:"1px solid var(--border)", margin:"10px 0 8px"}}/>
          <div style={{fontSize:11, color:"var(--muted)", textTransform:"uppercase", letterSpacing:".06em", marginBottom:6}}>По типам</div>
          {D.ROOM_TYPES.map(rt => (
            <div key={rt.code} className="leg">
              <span className="lab"><span className="chip">{rt.code}</span>{rt.name}</span>
              <strong>{rt.occ}/{rt.total} <span style={{color:"var(--muted-2)", fontWeight:400}}>({Math.round(rt.occ/rt.total*100)}%)</span></strong>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function HKCard(){
  const h = D.HK;
  const total = h.dirty+h.clean+h.pickup+h.inspected+h.ooo+h.oos;
  const seg = (n, c) => ({width:`${n/total*100}%`, background:c});
  return (
    <div className="card" style={{gridColumn:"span 2"}}>
      <div className="card-head">
        <div className="card-title">Housekeeping</div>
        <a className="btn sm ghost" href="housekeep.html">Открыть борд <Icon name="chevRight" size={12}/></a>
      </div>
      <div className="card-body">
        <div className="stackbar" style={{marginBottom:12}}>
          <div className="seg" style={seg(h.dirty,"var(--hk-dirty)")}/>
          <div className="seg" style={seg(h.pickup,"var(--hk-pickup)")}/>
          <div className="seg" style={seg(h.clean,"var(--hk-clean)")}/>
          <div className="seg" style={seg(h.inspected,"var(--hk-inspected)")}/>
          <div className="seg" style={seg(h.ooo,"var(--hk-ooo)")}/>
          <div className="seg" style={seg(h.oos,"var(--hk-oos)")}/>
        </div>
        <div className="grid g3" style={{gap:10}}>
          <HKStat c="hk-dirty" n={h.dirty} lab="Dirty"/>
          <HKStat c="hk-pickup" n={h.pickup} lab="Pickup"/>
          <HKStat c="hk-clean" n={h.clean} lab="Clean"/>
          <HKStat c="hk-inspected" n={h.inspected} lab="Inspected"/>
          <HKStat c="hk-ooo" n={h.ooo} lab="OOO"/>
          <HKStat c="hk-oos" n={h.oos} lab="OOS"/>
        </div>
      </div>
    </div>
  );
}
function HKStat({c,n,lab}){
  return (
    <div style={{display:"flex",alignItems:"center",gap:8,padding:"4px 0"}}>
      <span className={`badge ${c}`} style={{minWidth:34,justifyContent:"center"}}>{n}</span>
      <span style={{fontSize:12,color:"var(--muted)"}}>{lab}</span>
    </div>
  );
}

function ArrivalsTable(){
  const counts = {
    all: D.ARRIVALS.length,
    pending: D.ARRIVALS.filter(a=>a.st==="confirmed").length,
    in: D.ARRIVALS.filter(a=>a.st==="checked-in").length,
    ns: D.ARRIVALS.filter(a=>a.st==="no-show").length,
  };
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">Заезды сегодня <span className="count">· {counts.all}</span></div>
        <div className="ptabs">
          <div className="pt on">Все <span className="count">{counts.all}</span></div>
          <div className="pt">Ожидают <span className="count">{counts.pending}</span></div>
          <div className="pt">Заехали <span className="count">{counts.in}</span></div>
          <div className="pt">No-show <span className="count">{counts.ns}</span></div>
        </div>
      </div>
      <div className="card-body flush" style={{maxHeight:360, overflow:"auto"}}>
        <table className="t">
          <thead><tr>
            <th>Гость</th><th>Номер</th><th>ETA</th><th>Ночи</th><th>Источник</th><th>Статус</th><th></th>
          </tr></thead>
          <tbody>
            {D.ARRIVALS.map(a => (
              <tr key={a.conf}>
                <td>
                  <a className="guest" href="booking-detail.html">
                    <span className="av">{a.g.split(" ").map(x=>x[0]).slice(0,2).join("")}</span>
                    <span>
                      <span className="nm">{a.g} {a.vip && <span className="badge vip" style={{marginLeft:4}}>VIP</span>}</span>
                      <div className="sub"><span className="conf">{a.conf}</span> · {a.adults} взр · {a.rate}</div>
                    </span>
                  </a>
                </td>
                <td className="tnum">{a.room} <span style={{color:"var(--muted)",fontSize:11}}>· {a.type}</span></td>
                <td className="tnum">{a.eta}</td>
                <td className="tnum">{a.nights}</td>
                <td style={{color:"var(--muted)"}}>{a.src}</td>
                <td><span className={`badge ${a.st}`}><span className="dot"/>{a.st==="confirmed"?"Ожидает":a.st==="checked-in"?"Заехал":"No-show"}</span></td>
                <td className="r">
                  {a.st==="confirmed" && <button className="btn xs primary"><Icon name="key" size={11}/> Check-in</button>}
                  {a.st==="checked-in" && <button className="btn xs ghost"><Icon name="more" size={11}/></button>}
                  {a.st==="no-show" && <button className="btn xs">Обработать</button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function DeparturesTable(){
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">Выезды сегодня <span className="count">· {D.DEPARTURES.length}</span></div>
        <div className="ptabs">
          <div className="pt on">Все</div>
          <div className="pt">К выезду <span className="count">3</span></div>
          <div className="pt">Выехали <span className="count">6</span></div>
        </div>
      </div>
      <div className="card-body flush" style={{maxHeight:360, overflow:"auto"}}>
        <table className="t">
          <thead><tr>
            <th>Гость</th><th>Номер</th><th>ETD</th><th className="r">Баланс</th><th>Статус</th><th></th>
          </tr></thead>
          <tbody>
            {D.DEPARTURES.map(d => (
              <tr key={d.conf}>
                <td>
                  <a className="guest" href="booking-detail.html">
                    <span className="av">{d.g.split(" ").map(x=>x[0]).slice(0,2).join("")}</span>
                    <span>
                      <span className="nm">{d.g} {d.vip && <span className="badge vip" style={{marginLeft:4}}>VIP</span>}</span>
                      <div className="sub"><span className="conf">{d.conf}</span>{d.note?` · ${d.note}`:""}</div>
                    </span>
                  </a>
                </td>
                <td className="tnum">{d.room} <span style={{color:"var(--muted)",fontSize:11}}>· {d.type}</span></td>
                <td className="tnum">{d.etd}</td>
                <td className="r tnum">
                  {d.balance>0 
                    ? <span style={{color:"var(--cancelled)",fontWeight:600}}>{money(d.balance)}</span>
                    : <span style={{color:"var(--muted)"}}>—</span>}
                </td>
                <td><span className={`badge ${d.st==="due-out"?"no-show":"checked-out"}`}><span className="dot"/>{d.st==="due-out"?"К выезду":"Выехал"}</span></td>
                <td className="r">
                  {d.st==="due-out" && <button className="btn xs primary"><Icon name="logout" size={11}/> Check-out</button>}
                  {d.st==="checked-out" && <button className="btn xs ghost"><Icon name="more" size={11}/></button>}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function AlertsCard(){
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">Алерты <span className="count">· {D.ALERTS.length}</span></div>
        <button className="btn xs ghost">Все</button>
      </div>
      <div className="card-body flush">
        {D.ALERTS.map((a,i)=>(
          <div key={i} className={`alert ${a.sev}`}>
            <div className="indic"/>
            <div className="tx">
              <strong>{a.ti}</strong>
              <div className="sub">{a.sub}</div>
              <div className="ts">{a.ts}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function ForecastCard(){
  // mock 7-day occupancy forecast
  const fc = [
    { d:"пн 20", p:64, r:118, adr:7400 },
    { d:"вт 21", p:71, r:131, adr:7500 },
    { d:"ср 22", p:102, r:187, adr:7900, over:true },
    { d:"чт 23", p:88, r:162, adr:8100 },
    { d:"пт 24", p:94, r:173, adr:8600 },
    { d:"сб 25", p:96, r:177, adr:8800 },
    { d:"вс 26", p:82, r:151, adr:8200 },
  ];
  const max = 110;
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">Прогноз загрузки · 7 дней</div>
        <div className="ptabs"><div className="pt on">Occ %</div><div className="pt">ADR</div></div>
      </div>
      <div className="card-body">
        <div style={{display:"flex", alignItems:"flex-end", gap:8, height:140, padding:"4px 0 6px"}}>
          {fc.map(d => (
            <div key={d.d} style={{flex:1, display:"flex", flexDirection:"column", alignItems:"center", gap:6}}>
              <div style={{fontSize:11, color:d.over?"var(--cancelled)":"var(--fg)",fontWeight:600, fontVariantNumeric:"tabular-nums"}}>{d.p}%</div>
              <div style={{width:"100%", height:100, position:"relative", background:"var(--surface-2)", borderRadius:4, overflow:"hidden"}}>
                <div style={{position:"absolute", bottom:0, left:0, right:0, height:`${Math.min(d.p, 100)/max*100}%`, background: d.over?"var(--cancelled)":"var(--accent)", borderRadius: d.p>=100?"0":"0"}}/>
                {d.over && <div style={{position:"absolute", top:0, left:0, right:0, height:`${(d.p-100)/max*100}%`, background:"var(--cancelled)", opacity:.4, borderTop:"2px dashed var(--cancelled)"}}/>}
                <div style={{position:"absolute", bottom:`${100/max*100}%`, left:0, right:0, borderTop:"1px dashed var(--border-strong)"}}/>
              </div>
              <div style={{fontSize:11, color:"var(--muted)", fontFamily:"var(--font-mono)"}}>{d.d}</div>
            </div>
          ))}
        </div>
        <div style={{display:"flex", justifyContent:"space-between", fontSize:11, color:"var(--muted)", paddingTop:10, borderTop:"1px solid var(--border)", marginTop:6}}>
          <span>Пунктир — 100% capacity</span>
          <span style={{color:"var(--cancelled)"}}><Icon name="alert" size={11}/> Овербукинг 22 апр: +3 брони</span>
        </div>
      </div>
    </div>
  );
}

function RoomsMatrix(){
  // 24x10 = 240 cells; we have 184 rooms so we'll fill 184
  const cells = [];
  let occ = 118, vac = 60, ooo = 4, oos = 2, arr = 12, dep = 9;
  const total = 184;
  for (let i=0; i<total; i++){
    let cls = "";
    if (dep>0){ cls="dep"; dep--; }
    else if (arr>0){ cls="arr"; arr--; }
    else if (ooo>0){ cls="ooo"; ooo--; }
    else if (oos>0){ cls="oos"; oos--; }
    else if (occ>0){ cls="occ"; occ--; }
    else vac--;
    cells.push(cls);
  }
  // shuffle a bit for visual realism
  const shuffled = [...cells];
  for (let i=shuffled.length-1; i>0; i--){
    const j = (i*13+7) % (i+1);
    [shuffled[i], shuffled[j]] = [shuffled[j], shuffled[i]];
  }
  return (
    <div className="card">
      <div className="card-head">
        <div className="card-title">Мини-шахматка <span className="count">· 184 номера</span></div>
        <a className="btn sm ghost" href="tape.html">Полная <Icon name="chevRight" size={12}/></a>
      </div>
      <div className="card-body">
        <div className="matrix">
          {shuffled.map((c,i)=><div key={i} className={`m ${c}`} title={`Номер #${i+1}`}/>)}
        </div>
        <div style={{display:"flex", gap:14, flexWrap:"wrap", marginTop:12, fontSize:11}}>
          <span style={{display:"flex",alignItems:"center",gap:5}}><span className="m occ" style={{width:10,height:10,borderRadius:2,display:"inline-block"}}/> Занято</span>
          <span style={{display:"flex",alignItems:"center",gap:5}}><span className="m arr" style={{width:10,height:10,borderRadius:2,display:"inline-block"}}/> Заезд</span>
          <span style={{display:"flex",alignItems:"center",gap:5}}><span className="m dep" style={{width:10,height:10,borderRadius:2,display:"inline-block"}}/> Выезд</span>
          <span style={{display:"flex",alignItems:"center",gap:5}}><span style={{width:10,height:10,borderRadius:2,display:"inline-block",background:"var(--surface-2)",border:"1px solid var(--border)"}}/> Свободно</span>
          <span style={{display:"flex",alignItems:"center",gap:5}}><span className="m ooo" style={{width:10,height:10,borderRadius:2,display:"inline-block"}}/> OOO/OOS</span>
        </div>
      </div>
    </div>
  );
}

function Dashboard(){
  return (
    <Shell current="dashboard">
      <div className="page-head">
        <h1 className="page-title">Доброе утро, Анна</h1>
        <span className="page-sub">Понедельник, 20 апреля 2026 · смена 08:00–20:00</span>
        <div className="actions">
          <button className="btn sm"><Icon name="refresh" size={12}/> Обновить</button>
          <button className="btn sm"><Icon name="print" size={12}/> Отчёт смены</button>
          <button className="btn sm primary"><Icon name="moon" size={12}/> Запустить аудит</button>
        </div>
      </div>

      <KpiRow/>

      <div className="grid g4">
        <OccupancyCard/>
        <HKCard/>
      </div>

      <div className="grid g2">
        <ArrivalsTable/>
        <DeparturesTable/>
      </div>

      <div className="grid g3">
        <AlertsCard/>
        <ForecastCard/>
        <RoomsMatrix/>
      </div>
    </Shell>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<Dashboard/>);
