// Shared app shell: sidebar + topbar + command palette + theme tweak.
// All screens wrap themselves in <Shell current="..."/>.
const { useState, useEffect, useRef } = React;

const NAV = [
  { sec: "Главное", items: [
    { id:"dashboard",  ti:"Дашборд",        icon:"dashboard" },
    { id:"tape",       ti:"Шахматка",       icon:"calendar",  count:"14 д" },
    { id:"bookings",   ti:"Брони",          icon:"bookings",  count:"247" },
    { id:"profiles",   ti:"Профили гостей", icon:"users" },
  ]},
  { sec: "Операции", items: [
    { id:"new",        ti:"Новая бронь",     icon:"plus" },
    { id:"housekeep",  ti:"Housekeeping",    icon:"broom",   count:"60" },
    { id:"audit",      ti:"Ночной аудит",    icon:"moon" },
    { id:"cashier",    ti:"Касса",           icon:"cash" },
  ]},
  { sec: "Система", items: [
    { id:"config",     ti:"Настройки",       icon:"settings" },
  ]},
];

const PAGE_TITLES = {
  dashboard: "Дашборд",
  tape: "Шахматка",
  bookings: "Брони",
  "booking-detail": "Бронь",
  profiles: "Профили гостей",
  new: "Новая бронь",
  housekeep: "Housekeeping",
  audit: "Ночной аудит",
  cashier: "Касса",
  config: "Настройки",
};

function Sidebar({ current, narrow }){
  return (
    <aside className="sidebar">
      <div className="logo">
        <div className="mark">GB</div>
        <div className="name">Grand Baltic<small>PMS · 2026-04-20</small></div>
      </div>

      {NAV.map(sec => (
        <React.Fragment key={sec.sec}>
          <div className="nav-section">{sec.sec}</div>
          {sec.items.map(it => (
            <a key={it.id} href={`${it.id}.html`} className={`nav-item ${current===it.id?"active":""}`}>
              <Icon name={it.icon}/>
              <span className="lbl">{it.ti}</span>
              {it.count && <span className="count">{it.count}</span>}
            </a>
          ))}
        </React.Fragment>
      ))}

      <div className="side-foot">
        <div className="me">
          <div className="av">АК</div>
          <div className="who">
            А. Кузнецова
            <div className="role">Администратор · смена 08:00</div>
          </div>
        </div>
      </div>
    </aside>
  );
}

function Topbar({ current, openPalette }){
  const title = PAGE_TITLES[current] || "—";
  return (
    <div className="topbar">
      <div className="crumbs">
        <span>Grand Baltic</span>
        <Icon name="chevRight" size={12} style={{color:"var(--muted-2)"}}/>
        <span className="cur">{title}</span>
      </div>
      <div className="searchbox" onClick={openPalette}>
        <Icon name="search" size={14}/>
        <span>Поиск бронирования, гостя, номера…</span>
        <span className="kbd">⌘K</span>
      </div>
      <span className="biz-date">Биз. дата · 20 апр 2026 · пн</span>
      <div className="spacer"/>
      <button className="btn primary" onClick={()=>location.href="new.html"}>
        <Icon name="plus" size={14}/> Новая бронь
      </button>
      <div className="icon-btn" title="Уведомления">
        <Icon name="bell"/>
        <span className="badge"/>
      </div>
      <ThemeToggle/>
    </div>
  );
}

function ThemeToggle(){
  const [theme, setTheme] = useState(() => document.documentElement.getAttribute("data-theme") || "light");
  useEffect(()=>{
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("pms:theme", theme);
  }, [theme]);
  return (
    <div className="icon-btn" onClick={()=>setTheme(t=>t==="light"?"dark":"light")} title="Тема">
      <Icon name={theme==="light"?"moon":"sun"}/>
    </div>
  );
}

// ---- COMMAND PALETTE ----
const PALETTE_ACTIONS = [
  { g:"Переход", id:"go-dashboard", ti:"Перейти к Дашборду",       sub:"G D", href:"dashboard.html", icon:"dashboard" },
  { g:"Переход", id:"go-tape",      ti:"Открыть Шахматку",         sub:"G T", href:"tape.html",     icon:"calendar" },
  { g:"Переход", id:"go-bookings",  ti:"Список броней",            sub:"G B", href:"bookings.html", icon:"bookings" },
  { g:"Переход", id:"go-hk",        ti:"Housekeeping-борд",        sub:"G H", href:"housekeep.html",icon:"broom" },
  { g:"Переход", id:"go-audit",     ti:"Ночной аудит",             sub:"G N", href:"audit.html",    icon:"moon" },
  { g:"Переход", id:"go-cashier",   ti:"Касса / Смена",            sub:"G C", href:"cashier.html",  icon:"cash" },
  { g:"Действия", id:"new-book",    ti:"Создать новую бронь",      sub:"⌘N",  href:"new.html",      icon:"plus" },
  { g:"Действия", id:"checkin",     ti:"Check-in — BK-24018 Иванов",sub:"Enter", href:"booking-detail.html", icon:"key" },
  { g:"Действия", id:"checkout",    ti:"Check-out — 201 Белов",    sub:"",    href:"booking-detail.html", icon:"logout" },
  { g:"Поиск",   id:"guest-ivanov", ti:"Иванов А.П. · VIP · 508",  sub:"GP-0012", href:"booking-detail.html", icon:"user" },
  { g:"Поиск",   id:"guest-muller", ti:"Müller S. · VIP · 512",    sub:"GP-0189", href:"booking-detail.html", icon:"user" },
  { g:"Поиск",   id:"room-302",     ti:"Номер 302 — OOO 3-й день", sub:"",    href:"housekeep.html", icon:"alert" },
];

function CommandPalette({ open, onClose }){
  const [q, setQ] = useState("");
  const [sel, setSel] = useState(0);
  const inputRef = useRef();

  useEffect(()=>{ if(open){ inputRef.current?.focus(); setQ(""); setSel(0); } }, [open]);

  const filtered = PALETTE_ACTIONS.filter(a =>
    !q || a.ti.toLowerCase().includes(q.toLowerCase()) || a.g.toLowerCase().includes(q.toLowerCase())
  );

  const groups = [...new Set(filtered.map(a => a.g))];

  const onKey = (e) => {
    if (e.key === "Escape") onClose();
    else if (e.key === "ArrowDown") { setSel(s => Math.min(s+1, filtered.length-1)); e.preventDefault(); }
    else if (e.key === "ArrowUp")   { setSel(s => Math.max(s-1, 0)); e.preventDefault(); }
    else if (e.key === "Enter") {
      const target = filtered[sel];
      if (target?.href) location.href = target.href;
    }
  };

  if (!open) return null;

  return (
    <div className="palette-overlay on" onClick={onClose}>
      <div className="palette" onClick={e=>e.stopPropagation()}>
        <div className="in">
          <Icon name="search" size={18} style={{color:"var(--muted)"}}/>
          <input
            ref={inputRef}
            placeholder="Ищите броню, гостя, номер или команду…"
            value={q}
            onChange={e=>{setQ(e.target.value); setSel(0);}}
            onKeyDown={onKey}
          />
          <span className="kbd">ESC</span>
        </div>
        <div className="list">
          {filtered.length === 0 && (
            <div className="empty" style={{padding:"30px 16px"}}>Ничего не найдено</div>
          )}
          {groups.map(g => (
            <React.Fragment key={g}>
              <div className="group">{g}</div>
              {filtered.filter(a => a.g === g).map((a) => {
                const i = filtered.indexOf(a);
                return (
                  <a href={a.href} key={a.id} className={`item ${i===sel?"sel":""}`}>
                    <Icon name={a.icon}/>
                    <span>{a.ti}</span>
                    {a.sub && <span className="sub">{a.sub}</span>}
                  </a>
                );
              })}
            </React.Fragment>
          ))}
        </div>
      </div>
    </div>
  );
}

// ---- TWEAKS (density / sidebar / accent) ----
const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "density": "medium",
  "sidebar": "wide",
  "accent": "blue",
  "theme": "light"
}/*EDITMODE-END*/;

function applyTweaks(t){
  document.documentElement.setAttribute("data-theme", t.theme || "light");
  // density via font-size scale on body
  const sizes = { compact:"12px", medium:"13px", cozy:"14px" };
  document.body.style.fontSize = sizes[t.density] || "13px";
  // accent palette
  const accents = {
    blue:   { a:"#2563eb", h:"#1d4ed8", s:"#eff6ff" },
    indigo: { a:"#4f46e5", h:"#4338ca", s:"#eef2ff" },
    teal:   { a:"#0d9488", h:"#0f766e", s:"#f0fdfa" },
    slate:  { a:"#334155", h:"#1e293b", s:"#f1f5f9" },
  };
  const ac = accents[t.accent] || accents.blue;
  document.documentElement.style.setProperty("--accent", ac.a);
  document.documentElement.style.setProperty("--accent-hover", ac.h);
  document.documentElement.style.setProperty("--accent-soft", ac.s);
}

function Tweaks(){
  const [on, setOn] = useState(false);
  const [t, setT] = useState(()=>{ try{ return {...TWEAK_DEFAULTS, ...JSON.parse(localStorage.getItem("pms:tweaks")||"{}")}; }catch{ return TWEAK_DEFAULTS; }});

  useEffect(()=>{
    const handler = (e)=>{
      if (e.data?.type === "__activate_edit_mode") setOn(true);
      else if (e.data?.type === "__deactivate_edit_mode") setOn(false);
    };
    window.addEventListener("message", handler);
    window.parent.postMessage({type:"__edit_mode_available"}, "*");
    return ()=>window.removeEventListener("message", handler);
  }, []);

  useEffect(()=>{ applyTweaks(t); localStorage.setItem("pms:tweaks", JSON.stringify(t)); }, [t]);

  const update = (k, v)=>{
    const next = {...t, [k]:v};
    setT(next);
    window.parent.postMessage({type:"__edit_mode_set_keys", edits:{[k]:v}}, "*");
    if (k === "sidebar") document.querySelector(".app")?.classList.toggle("narrow", v==="narrow");
  };

  // apply sidebar narrow on mount
  useEffect(()=>{
    document.querySelector(".app")?.classList.toggle("narrow", t.sidebar==="narrow");
  }, []);

  const Seg = ({k, opts}) => (
    <div className="seg">
      {opts.map(o => (
        <button key={o.v} className={t[k]===o.v?"on":""} onClick={()=>update(k,o.v)}>{o.l}</button>
      ))}
    </div>
  );

  return (
    <div id="tweaks" className={on?"on":""}>
      <h4>Tweaks <small>панель управления</small></h4>
      <div className="row">
        <span>Плотность</span>
        <Seg k="density" opts={[{v:"compact",l:"Compact"},{v:"medium",l:"Medium"},{v:"cozy",l:"Cozy"}]}/>
      </div>
      <div className="row">
        <span>Сайдбар</span>
        <Seg k="sidebar" opts={[{v:"wide",l:"Wide"},{v:"narrow",l:"Icons"}]}/>
      </div>
      <div className="row">
        <span>Акцент</span>
        <Seg k="accent" opts={[{v:"blue",l:"Blue"},{v:"indigo",l:"Indigo"},{v:"teal",l:"Teal"},{v:"slate",l:"Slate"}]}/>
      </div>
      <div className="row">
        <span>Тема</span>
        <Seg k="theme" opts={[{v:"light",l:"Light"},{v:"dark",l:"Dark"}]}/>
      </div>
    </div>
  );
}

function Shell({ current, children }){
  const [paletteOpen, setPaletteOpen] = useState(false);

  // Global ⌘K / Ctrl+K handler
  useEffect(()=>{
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase()==="k"){
        e.preventDefault(); setPaletteOpen(true);
      }
    };
    window.addEventListener("keydown", onKey);
    return ()=>window.removeEventListener("keydown", onKey);
  }, []);

  // Restore saved tweaks on load
  useEffect(()=>{
    try{
      const saved = {...TWEAK_DEFAULTS, ...JSON.parse(localStorage.getItem("pms:tweaks")||"{}")};
      applyTweaks(saved);
      document.querySelector(".app")?.classList.toggle("narrow", saved.sidebar==="narrow");
    }catch{}
  }, []);

  return (
    <div className="app">
      <Sidebar current={current}/>
      <div className="main">
        <Topbar current={current} openPalette={()=>setPaletteOpen(true)}/>
        <div className="content">{children}</div>
      </div>
      <CommandPalette open={paletteOpen} onClose={()=>setPaletteOpen(false)}/>
      <Tweaks/>
    </div>
  );
}

Object.assign(window, { Shell, Sidebar, Topbar, NAV });
