// ===== SETTINGS / CONFIG =====
function ConfigScreen(){
  const [sec, setSec] = React.useState("hotel");
  const sections = [
    {k:"hotel", ti:"Отель", icon:"settings"},
    {k:"rooms", ti:"Номера и типы", icon:"bed"},
    {k:"rates", ti:"Тарифы", icon:"sparkles"},
    {k:"channels", ti:"Каналы продаж", icon:"flag"},
    {k:"users", ti:"Пользователи", icon:"users"},
    {k:"taxes", ti:"Налоги", icon:"cash"},
    {k:"reports", ti:"Отчёты", icon:"print"},
  ];

  return (
    <Shell current="config">
      <div className="page-head">
        <h1 className="page-title">Настройки</h1>
        <span className="page-sub">Изменения логируются в журнале аудита</span>
      </div>

      <div style={{display:"grid",gridTemplateColumns:"220px 1fr",gap:14}}>
        <div className="card" style={{padding:6,alignSelf:"flex-start"}}>
          {sections.map(s=>(
            <div key={s.k} className={`nav-item ${sec===s.k?"active":""}`} onClick={()=>setSec(s.k)}>
              <Icon name={s.icon}/> <span className="lbl">{s.ti}</span>
            </div>
          ))}
        </div>

        <div className="card">
          {sec==="hotel" && (
            <div className="card-body">
              <h3 style={{margin:"0 0 14px",fontSize:15}}>Параметры отеля</h3>
              <div className="grid g2" style={{maxWidth:680}}>
                <div className="field"><div className="lab">Название</div><input className="input" defaultValue="Grand Baltic Hotel"/></div>
                <div className="field"><div className="lab">Юр. название</div><input className="input" defaultValue='ООО "Балтик-Отель"'/></div>
                <div className="field"><div className="lab">ИНН</div><input className="input" defaultValue="7801234567"/></div>
                <div className="field"><div className="lab">Часовой пояс</div><select className="select"><option>Europe/Moscow (UTC+3)</option></select></div>
                <div className="field"><div className="lab">Валюта</div><select className="select"><option>RUB (₽)</option></select></div>
                <div className="field"><div className="lab">Бизнес-дата</div><input className="input" defaultValue="2026-04-20"/></div>
                <div className="field"><div className="lab">Check-in по умолчанию</div><input className="input" defaultValue="14:00"/></div>
                <div className="field"><div className="lab">Check-out по умолчанию</div><input className="input" defaultValue="12:00"/></div>
                <div className="field" style={{gridColumn:"1/-1"}}><div className="lab">Адрес</div><input className="input" defaultValue="Санкт-Петербург, Невский пр., 12"/></div>
              </div>
              <div style={{marginTop:16,display:"flex",gap:8}}>
                <button className="btn primary">Сохранить</button>
                <button className="btn">Отмена</button>
              </div>
            </div>
          )}
          {sec!=="hotel" && <div className="stub"><div className="wip">Design in progress</div><h3>Раздел «{sections.find(s=>s.k===sec).ti}»</h3><div>Макет в работе</div></div>}
        </div>
      </div>
    </Shell>
  );
}
ReactDOM.createRoot(document.getElementById("root")).render(<ConfigScreen/>);
