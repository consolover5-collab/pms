// ===== BOOKING DETAIL — Chen Li / BK-24025 / DLX 411 =====
const BK = window.PMS_DATA;
const fm = (n) => n.toLocaleString("ru-RU") + " ₽";

function FolioWindow({ w, letter }){
  return (
    <div className="folio-win">
      <div className="fh">
        <div>
          <div className="ti">Окно {letter} · {w.label}</div>
          <div className="who">Плательщик: {w.payer}</div>
        </div>
        <div style={{display:"flex",gap:6}}>
          <button className="btn xs"><Icon name="plus" size={11}/> Начисление</button>
          <button className="btn xs"><Icon name="cash" size={11}/> Платёж</button>
          <button className="btn xs ghost"><Icon name="more" size={11}/></button>
        </div>
      </div>
      <table className="t">
        <thead><tr>
          <th style={{width:100}}>Дата</th>
          <th>Описание</th>
          <th className="r" style={{width:50}}>Кол-во</th>
          <th className="r" style={{width:110}}>Сумма</th>
          <th style={{width:40}}></th>
        </tr></thead>
        <tbody>
          {w.lines.map((l,i)=>(
            <tr key={i}>
              <td className="tnum" style={{color:"var(--muted)"}}>{l.date}</td>
              <td>{l.desc}</td>
              <td className="r tnum">{l.qty}</td>
              <td className="r tnum">{fm(l.amt)}</td>
              <td className="r"><Icon name="more" size={13} style={{color:"var(--muted)"}}/></td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="totals">
        <div className="t"><div className="k">Начислено</div><div className="v">{fm(w.total)}</div></div>
        <div className="t"><div className="k">Оплачено</div><div className="v neg">{fm(w.paid)}</div></div>
        <div className="t" style={{marginLeft:"auto"}}><div className="k">Баланс</div><div className={`v ${w.balance>0?"pos":"zero"}`}>{w.balance>0?fm(w.balance):"0 ₽"}</div></div>
      </div>
    </div>
  );
}

function BookingDetail(){
  const f = BK.FOLIO_SAMPLE;
  const [tab, setTab] = React.useState("folio");

  return (
    <Shell current="booking-detail">
      <div style={{display:"flex",alignItems:"center",gap:8,fontSize:12,color:"var(--muted)",marginBottom:-4}}>
        <a href="bookings.html" style={{color:"var(--muted)"}}>← Брони</a>
        <span>·</span>
        <span>{f.booking}</span>
      </div>

      <div style={{display:"flex",alignItems:"flex-start",gap:14,paddingBottom:12,borderBottom:"1px solid var(--border)"}}>
        <div className="av" style={{width:52,height:52,fontSize:18,background:"var(--accent-soft)",color:"var(--accent)"}}>CL</div>
        <div style={{flex:1}}>
          <div style={{display:"flex",alignItems:"center",gap:10}}>
            <h1 style={{margin:0,fontSize:22,fontWeight:600,letterSpacing:"-.02em"}}>{f.guest}</h1>
            <span className="badge checked-in"><span className="dot"/>Заехал</span>
            <span className="badge outline">CORP · Alibaba Group</span>
            <span className="chip">CN</span>
          </div>
          <div style={{display:"flex",gap:18,fontSize:12,color:"var(--muted)",marginTop:4}}>
            <span><span className="conf" style={{color:"var(--accent)",fontFamily:"var(--font-mono)",fontWeight:500}}>{f.booking}</span></span>
            <span>Номер <strong style={{color:"var(--fg)"}}>411 · DLX</strong></span>
            <span>Заезд <strong style={{color:"var(--fg)"}}>20 апр 14:00</strong></span>
            <span>Выезд <strong style={{color:"var(--fg)"}}>24 апр 12:00</strong></span>
            <span>4 ночи · 2 взр</span>
            <span>Источник <strong style={{color:"var(--fg)"}}>Экспедия</strong></span>
          </div>
        </div>
        <div style={{display:"flex",gap:6,alignSelf:"flex-start"}}>
          <button className="btn"><Icon name="print" size={13}/> Счёт</button>
          <button className="btn"><Icon name="more" size={13}/></button>
          <button className="btn primary"><Icon name="logout" size={13}/> Check-out</button>
        </div>
      </div>

      <div className="tabs-bar">
        {[
          {id:"folio",l:"Финансы"},
          {id:"stay",l:"Проживание"},
          {id:"services",l:"Услуги"},
          {id:"history",l:"История"},
          {id:"notes",l:"Заметки",count:3},
        ].map(t => (
          <div key={t.id} className={`tb ${tab===t.id?"on":""}`} onClick={()=>setTab(t.id)}>
            {t.l} {t.count && <span className="count">{t.count}</span>}
          </div>
        ))}
      </div>

      {tab==="folio" && (
        <div style={{display:"grid",gridTemplateColumns:"1fr 320px",gap:14}}>
          <div>
            <FolioWindow w={f.window_A} letter="A"/>
            <FolioWindow w={f.window_B} letter="B"/>
            <button className="btn sm" style={{marginTop:4}}><Icon name="plus" size={12}/> Добавить окно</button>
          </div>

          <div className="col">
            <div className="card">
              <div className="card-head"><div className="card-title">Итого по брони</div></div>
              <div className="card-body">
                <div className="leg"><span className="lab">Окно A (гость)</span><strong>{fm(f.window_A.balance)}</strong></div>
                <div className="leg"><span className="lab">Окно B (корп.)</span><strong style={{color:"var(--muted)"}}>0 ₽</strong></div>
                <div style={{borderTop:"1px solid var(--border)",margin:"8px 0"}}/>
                <div className="leg"><span className="lab" style={{color:"var(--fg)",fontWeight:600}}>К оплате при выезде</span><strong style={{color:"var(--cancelled)",fontSize:15}}>{fm(f.window_A.balance)}</strong></div>
                <button className="btn primary" style={{width:"100%",justifyContent:"center",marginTop:10}}><Icon name="cash" size={13}/> Принять платёж</button>
              </div>
            </div>

            <div className="card">
              <div className="card-head"><div className="card-title">Гость</div><button className="btn xs ghost">Профиль →</button></div>
              <div className="card-body" style={{fontSize:12}}>
                <div style={{color:"var(--muted)",fontSize:11,marginBottom:2}}>ID профиля</div>
                <div className="tnum">GP-0321</div>
                <div style={{color:"var(--muted)",fontSize:11,margin:"8px 0 2px"}}>Email</div>
                <div>chen.li@ex.cn</div>
                <div style={{color:"var(--muted)",fontSize:11,margin:"8px 0 2px"}}>Телефон</div>
                <div className="tnum">+86 138 0013 8000</div>
                <div style={{color:"var(--muted)",fontSize:11,margin:"8px 0 2px"}}>Компания</div>
                <div>Alibaba Group</div>
                <div style={{color:"var(--muted)",fontSize:11,margin:"8px 0 2px"}}>Проживаний</div>
                <div>3 · LTV 98 000 ₽</div>
              </div>
            </div>

            <div className="card">
              <div className="card-head"><div className="card-title">Предпочтения</div></div>
              <div className="card-body" style={{fontSize:12,lineHeight:1.6}}>
                <div>🇬🇧 English speaker</div>
                <div>🥗 Vegetarian meals</div>
                <div>🛏️ Тихий номер, non-smoking</div>
              </div>
            </div>

            <div className="card">
              <div className="card-head"><div className="card-title">Активность</div></div>
              <div className="card-body" style={{fontSize:11.5}}>
                <Timeline items={[
                  {t:"20 апр 14:12", who:"А. Кузнецова", act:"Check-in · ключ выдан"},
                  {t:"20 апр 14:05", who:"—",            act:"Заезд по документам"},
                  {t:"18 апр 09:30", who:"Booking Engine", act:"Бронь подтверждена (CORP)"},
                  {t:"17 апр 22:14", who:"Chen Li",      act:"Бронь создана через Экспедия"},
                ]}/>
              </div>
            </div>
          </div>
        </div>
      )}

      {tab!=="folio" && <div className="stub"><div className="wip">Design in progress</div><h3>Вкладка «{tab}»</h3><div>Макет в работе — фокус текущей итерации на финансах и multi-window folio</div></div>}
    </Shell>
  );
}

function Timeline({ items }){
  return (
    <div style={{position:"relative"}}>
      {items.map((it,i)=>(
        <div key={i} style={{display:"flex",gap:10,paddingBottom:10,position:"relative"}}>
          <div style={{width:6,height:6,borderRadius:"50%",background:"var(--accent)",marginTop:5,flexShrink:0,position:"relative"}}>
            {i<items.length-1 && <div style={{position:"absolute",top:10,left:2,width:2,height:"calc(100% + 6px)",background:"var(--border)"}}/>}
          </div>
          <div style={{flex:1}}>
            <div>{it.act}</div>
            <div style={{color:"var(--muted)",fontSize:10.5,marginTop:1}}>{it.t} · {it.who}</div>
          </div>
        </div>
      ))}
    </div>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<BookingDetail/>);
