// ===== TAPE CHART (Шахматка) — 14 days, grouped by room type =====
const TD = window.PMS_DATA;
const DAYS_COUNT = 14;
const DAY_W = 90; // px per day column
const ROOM_W = 180;
const ROW_H = 30;

function TapeLegend(){
  const L = ({cls, lab}) => (
    <span style={{display:"inline-flex",alignItems:"center",gap:5,fontSize:11}}>
      <span className={`bar ${cls}`} style={{position:"relative",width:18,height:12,display:"inline-block",borderRadius:3,padding:0}}/>
      <span style={{color:"var(--muted)"}}>{lab}</span>
    </span>
  );
  return (
    <div style={{display:"flex",gap:14,flexWrap:"wrap",alignItems:"center"}}>
      <L cls="confirmed" lab="Подтверждена"/>
      <L cls="checked-in" lab="Заехал"/>
      <L cls="checked-out" lab="Выехал"/>
      <L cls="no-show" lab="No-show"/>
      <L cls="cancelled" lab="Отменена"/>
    </div>
  );
}

function TapeChart(){
  const [openGroups, setOpenGroups] = React.useState({STD:true, TWN:true, DLX:true, JR:true, SUITE:true});

  const groups = {};
  TD.TAPE_ROOMS.forEach(r => { (groups[r.type] ||= []).push(r); });
  const typeOrder = ["SUITE","JR","DLX","TWN","STD"];
  const typeName = {STD:"Standard",TWN:"Twin",DLX:"Deluxe",JR:"Junior Suite",SUITE:"Suite"};

  const hkColor = {clean:"var(--hk-clean)", dirty:"var(--hk-dirty)", pickup:"var(--hk-pickup)", inspected:"var(--hk-inspected)", ooo:"var(--hk-ooo)", oos:"var(--hk-oos)"};

  const totalW = ROOM_W + DAYS_COUNT * DAY_W;

  return (
    <div className="tape-wrap">
      <div style={{minWidth: totalW}}>
        {/* Header row */}
        <div style={{display:"grid", gridTemplateColumns:`${ROOM_W}px repeat(${DAYS_COUNT}, ${DAY_W}px)`, position:"sticky", top:0, zIndex:5, background:"var(--bg-subtle)", borderBottom:"1px solid var(--border)"}}>
          <div style={{padding:"7px 12px", fontSize:11, fontWeight:500, color:"var(--muted)", textTransform:"uppercase", letterSpacing:".04em", position:"sticky", left:0, background:"var(--bg-subtle)", zIndex:6, borderRight:"1px solid var(--border)"}}>Номер</div>
          {TD.DAYS.map(d => (
            <div key={d.date} style={{
              padding:"5px 4px", fontSize:11, textAlign:"center", fontWeight: d.today?600:500,
              color: d.today?"var(--accent)":"var(--muted)",
              background: d.today?"var(--accent-soft)":(d.weekend?"var(--bg-sunken)":"transparent"),
              borderRight: "1px solid var(--border)", borderBottom: d.today?"2px solid var(--accent)":"none",
            }}>
              <div>{d.day} {d.mon}</div>
              <div style={{fontSize:10, color: d.today?"var(--accent)":"var(--muted-2)", fontWeight:400}}>{d.dow}</div>
            </div>
          ))}
        </div>

        {typeOrder.map(tp => {
          const rooms = groups[tp] || [];
          if (rooms.length===0) return null;
          const sold = rooms.reduce((s,r)=> s + (r.bars.some(b=>b.s<=0 && b.s+b.l>0 && b.st!=="cancelled"&&b.st!=="checked-out"&&b.st!=="no-show")?1:0), 0);
          return (
            <React.Fragment key={tp}>
              <div
                onClick={()=>setOpenGroups(g=>({...g,[tp]:!g[tp]}))}
                style={{
                  padding:"6px 12px", background:"var(--bg-subtle)", borderBottom:"1px solid var(--border)",
                  fontSize:11, textTransform:"uppercase", letterSpacing:".06em", color:"var(--muted)", fontWeight:600,
                  display:"flex", alignItems:"center", gap:8, cursor:"pointer",
                  position:"sticky", left:0,
                }}
              >
                <Icon name="chevDown" size={12} style={{transform: openGroups[tp]?"rotate(0)":"rotate(-90deg)", transition:"transform .15s"}}/>
                <span>{typeName[tp]} ({tp})</span>
                <span style={{marginLeft:"auto",fontFamily:"var(--font-mono)",fontSize:10,color:"var(--muted-2)",fontWeight:400,textTransform:"none",letterSpacing:0}}>
                  {rooms.length} номеров · занято {sold}
                </span>
              </div>

              {openGroups[tp] && rooms.map(r => (
                <div key={r.n} style={{display:"flex", borderBottom:"1px solid var(--border)", position:"relative", height: ROW_H, background:"var(--surface)"}}>
                  {/* Room label cell (sticky) */}
                  <div style={{
                    width: ROOM_W, flexShrink:0, padding:"0 10px",
                    display:"flex", alignItems:"center", gap:8,
                    fontFamily:"var(--font-mono)", fontSize:12, fontWeight:500,
                    position:"sticky", left:0, background:"var(--surface)", zIndex:2,
                    borderRight:"1px solid var(--border)"
                  }}>
                    <span style={{width:8,height:8,borderRadius:"50%",background:hkColor[r.hk],flexShrink:0}} title={r.hk}/>
                    <span>{r.n}</span>
                    <span style={{color:"var(--muted)",fontSize:10,fontFamily:"var(--font-sans)"}}>{r.type}</span>
                  </div>

                  {/* day grid background */}
                  <div style={{position:"relative", width: DAYS_COUNT * DAY_W, height: ROW_H}}>
                    {TD.DAYS.map((d, di) => (
                      <div key={d.date} style={{
                        position:"absolute", top:0, bottom:0, left: di*DAY_W, width: DAY_W,
                        borderRight:"1px solid var(--border)",
                        background: d.today?"rgba(37,99,235,0.04)":(d.weekend?"var(--bg-subtle)":"transparent"),
                        boxShadow: d.today?"inset 2px 0 0 var(--accent)":"none",
                      }}/>
                    ))}
                    {/* bars */}
                    {r.bars.map((b, bi) => {
                      const startDay = Math.max(0, b.s);
                      const endDay = Math.min(DAYS_COUNT, b.s + b.l);
                      const span = endDay - startDay;
                      if (span <= 0) return null;
                      // half-day offset for arrival/departure
                      const isArrival = b.s >= 0;
                      const isDepart = b.s + b.l <= DAYS_COUNT;
                      const left = startDay * DAY_W + (isArrival ? DAY_W*0.4 : 0);
                      const right = (DAYS_COUNT - endDay) * DAY_W + (isDepart ? DAY_W*0.4 : 0);
                      const width = DAYS_COUNT*DAY_W - left - right;
                      const isOOO = b.st === "ooo";
                      return (
                        <div
                          key={bi}
                          className={`bar ${b.st}`}
                          onClick={()=>{ if(!isOOO) location.href="booking-detail.html"; }}
                          style={{
                            position:"absolute", top:3, bottom:3, left, width,
                            borderRadius:4, padding:"0 8px",
                            display:"flex", alignItems:"center", gap:4,
                            fontSize:11, fontWeight:500, whiteSpace:"nowrap", overflow:"hidden",
                            cursor: isOOO ? "default" : "pointer",
                          }}
                          title={`${b.g} · ${b.c}${b.vip?" · VIP":""}`}
                        >
                          {b.vip && <span style={{fontSize:10}}>★</span>}
                          <span style={{overflow:"hidden",textOverflow:"ellipsis"}}>{b.g}</span>
                          <span style={{marginLeft:"auto",fontFamily:"var(--font-mono)",fontSize:9,opacity:.7}}>{b.c.replace("BK-","")}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              ))}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}

function TapeScreen(){
  return (
    <Shell current="tape">
      <div className="page-head">
        <h1 className="page-title">Шахматка</h1>
        <span className="page-sub">20 апр – 03 мая 2026 · 14 дней · 23 номера в показе</span>
        <div className="actions">
          <div className="ptabs">
            <div className="pt on">14 дней</div>
            <div className="pt">30 дней</div>
            <div className="pt">90 дней</div>
          </div>
          <button className="btn sm"><Icon name="chevLeft" size={12}/></button>
          <button className="btn sm">Сегодня</button>
          <button className="btn sm"><Icon name="chevRight" size={12}/></button>
          <button className="btn sm"><Icon name="filter" size={12}/> Фильтры</button>
          <button className="btn sm primary" onClick={()=>location.href="new.html"}><Icon name="plus" size={12}/> Бронь</button>
        </div>
      </div>

      <div style={{display:"flex",alignItems:"center",gap:14,padding:"8px 12px",background:"var(--surface)",border:"1px solid var(--border)",borderRadius:8,fontSize:12,flexWrap:"wrap"}}>
        <TapeLegend/>
        <div style={{marginLeft:"auto",display:"flex",alignItems:"center",gap:10,color:"var(--muted)",flexWrap:"wrap"}}>
          <span>HK:</span>
          <span style={{display:"inline-flex",alignItems:"center",gap:4}}><span style={{width:8,height:8,borderRadius:"50%",background:"var(--hk-clean)"}}/>Clean</span>
          <span style={{display:"inline-flex",alignItems:"center",gap:4}}><span style={{width:8,height:8,borderRadius:"50%",background:"var(--hk-dirty)"}}/>Dirty</span>
          <span style={{display:"inline-flex",alignItems:"center",gap:4}}><span style={{width:8,height:8,borderRadius:"50%",background:"var(--hk-pickup)"}}/>Pickup</span>
          <span style={{display:"inline-flex",alignItems:"center",gap:4}}><span style={{width:8,height:8,borderRadius:"50%",background:"var(--hk-inspected)"}}/>Inspected</span>
          <span style={{display:"inline-flex",alignItems:"center",gap:4}}><span style={{width:8,height:8,borderRadius:"50%",background:"var(--hk-ooo)"}}/>OOO</span>
        </div>
      </div>

      <div className="card" style={{padding:0,overflow:"hidden"}}>
        <TapeChart/>
      </div>

      <div style={{display:"flex",gap:20,fontSize:11.5,color:"var(--muted)",padding:"2px 4px"}}>
        <span><span className="kbd">↑↓←→</span> навигация</span>
        <span><span className="kbd">Enter</span> открыть бронь</span>
        <span><span className="kbd">N</span> новая бронь в ячейке</span>
        <span>перетаскивание баров для смены номера/дат</span>
      </div>
    </Shell>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<TapeScreen/>);
