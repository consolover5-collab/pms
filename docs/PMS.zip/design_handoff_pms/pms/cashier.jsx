// ===== CASHIER / SHIFT =====
function CashierScreen(){
  const payments = [
    { t:"09:14", g:"Белов А.Н.",   bk:"BK-23987", typ:"Оплата номера",  method:"Карта",    amt:12400 },
    { t:"09:32", g:"García L.",    bk:"BK-23991", typ:"Оплата номера",  method:"Нал",      amt:14000 },
    { t:"10:05", g:"Müller S.",    bk:"BK-23995", typ:"Late check-out", method:"Карта",    amt:8200 },
    { t:"10:44", g:"Kuznetsova T.",bk:"BK-23994", typ:"Мини-бар",       method:"Карта",    amt:1800 },
    { t:"11:21", g:"Петров С.И.",  bk:"BK-24017", typ:"Депозит",        method:"Карта",    amt:12400 },
    { t:"11:58", g:"Иванов А.П.",  bk:"BK-24018", typ:"Депозит SUITE",  method:"Карта",    amt:37800 },
    { t:"12:14", g:"Ким Ю.Х.",     bk:"BK-24001", typ:"Late check-out", method:"Карта",    amt:3100 },
    { t:"12:40", g:"Смирнов Д.К.", bk:"BK-24020", typ:"Депозит",        method:"Нал",      amt:19200 },
    { t:"13:02", g:"Chen Li",      bk:"BK-24025", typ:"Завтрак ×2",     method:"CORP",     amt:2400, ref:true },
  ];
  const methods = {Карта:0,Нал:0,CORP:0};
  payments.forEach(p=>methods[p.method]+=p.amt);
  const total = payments.reduce((s,p)=>s+p.amt,0);

  return (
    <Shell current="cashier">
      <div className="page-head">
        <h1 className="page-title">Касса</h1>
        <span className="page-sub">Смена #842 · А. Кузнецова · открыта 08:00 · {payments.length} операций · {total.toLocaleString("ru-RU")} ₽</span>
        <div className="actions">
          <button className="btn sm"><Icon name="print" size={12}/> X-отчёт</button>
          <button className="btn sm"><Icon name="download" size={12}/> Экспорт</button>
          <button className="btn sm danger"><Icon name="logout" size={12}/> Закрыть смену</button>
        </div>
      </div>

      <div className="grid g4">
        <div className="kpi accent">
          <div className="lab">Оборот смены</div>
          <div className="val">{total.toLocaleString("ru-RU")}<span className="of"> ₽</span></div>
          <div className="foot">{payments.length} операций</div>
        </div>
        <div className="kpi">
          <div className="lab">Карта</div>
          <div className="val">{methods["Карта"].toLocaleString("ru-RU")}<span className="of"> ₽</span></div>
          <div className="foot">{payments.filter(p=>p.method==="Карта").length} операций</div>
        </div>
        <div className="kpi">
          <div className="lab">Наличные</div>
          <div className="val">{methods["Нал"].toLocaleString("ru-RU")}<span className="of"> ₽</span></div>
          <div className="foot">{payments.filter(p=>p.method==="Нал").length} операций</div>
        </div>
        <div className="kpi">
          <div className="lab">Корп. счёт</div>
          <div className="val">{methods["CORP"].toLocaleString("ru-RU")}<span className="of"> ₽</span></div>
          <div className="foot">без движения по кассе</div>
        </div>
      </div>

      <div className="grid" style={{gridTemplateColumns:"1fr 380px",gap:14}}>
        <div className="card">
          <div className="card-head">
            <div className="card-title">Операции смены</div>
            <div className="ptabs">
              <div className="pt on">Все</div>
              <div className="pt">Приход</div>
              <div className="pt">Расход</div>
              <div className="pt">Возвраты</div>
            </div>
          </div>
          <div className="card-body flush">
            <table className="t">
              <thead><tr>
                <th>Время</th><th>Гость / Бронь</th><th>Операция</th><th>Метод</th><th className="r">Сумма</th><th></th>
              </tr></thead>
              <tbody>
                {payments.map((p,i)=>(
                  <tr key={i}>
                    <td className="tnum" style={{color:"var(--muted)"}}>{p.t}</td>
                    <td>
                      <div className="guest">
                        <span className="av">{p.g.split(" ").map(x=>x[0]).slice(0,2).join("")}</span>
                        <span>
                          <span className="nm">{p.g}</span>
                          <div className="sub"><span style={{color:"var(--accent)",fontFamily:"var(--font-mono)"}}>{p.bk}</span></div>
                        </span>
                      </div>
                    </td>
                    <td>{p.typ}</td>
                    <td>
                      {p.method==="Карта" && <span className="chip">💳 Карта</span>}
                      {p.method==="Нал" && <span className="chip">💴 Нал</span>}
                      {p.method==="CORP" && <span className="chip">🏢 CORP</span>}
                    </td>
                    <td className="r tnum" style={{fontWeight:600}}>{p.amt.toLocaleString("ru-RU")} ₽</td>
                    <td className="r"><Icon name="more" size={13} style={{color:"var(--muted)"}}/></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="col">
          <div className="card">
            <div className="card-head"><div className="card-title">Быстрые действия</div></div>
            <div className="card-body">
              <div style={{display:"grid",gridTemplateColumns:"1fr 1fr",gap:8}}>
                <button className="btn"><Icon name="plus" size={13}/> Приход</button>
                <button className="btn"><Icon name="cash" size={13}/> Возврат</button>
                <button className="btn"><Icon name="download" size={13}/> Депозит</button>
                <button className="btn"><Icon name="print" size={13}/> Чек повторно</button>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-head"><div className="card-title">Сверка кассы</div></div>
            <div className="card-body" style={{fontSize:12}}>
              <div className="leg"><span className="lab">Стартовый остаток</span><strong>5 000 ₽</strong></div>
              <div className="leg"><span className="lab">Приход нал.</span><strong>+{methods["Нал"].toLocaleString("ru-RU")} ₽</strong></div>
              <div className="leg"><span className="lab">Расход</span><strong>0 ₽</strong></div>
              <div style={{borderTop:"1px solid var(--border)",margin:"8px 0"}}/>
              <div className="leg"><span className="lab" style={{fontWeight:600,color:"var(--fg)"}}>Ожидается в кассе</span><strong>{(methods["Нал"]+5000).toLocaleString("ru-RU")} ₽</strong></div>
              <div className="field" style={{marginTop:10}}>
                <div className="lab">Фактически в кассе</div>
                <input className="input" placeholder="Введите сумму…" defaultValue="38 200"/>
              </div>
            </div>
          </div>

          <div className="card">
            <div className="card-head"><div className="card-title">Открытые депозиты</div></div>
            <div className="card-body flush">
              <div style={{padding:"8px 14px",borderBottom:"1px solid var(--border)",fontSize:12,display:"flex",justifyContent:"space-between"}}>
                <div>Петров С.И. · 305</div><strong>12 400 ₽</strong>
              </div>
              <div style={{padding:"8px 14px",borderBottom:"1px solid var(--border)",fontSize:12,display:"flex",justifyContent:"space-between"}}>
                <div>Иванов А.П. · 508 <span className="badge vip">VIP</span></div><strong>37 800 ₽</strong>
              </div>
              <div style={{padding:"8px 14px",fontSize:12,display:"flex",justifyContent:"space-between"}}>
                <div>Смирнов Д.К. · 221</div><strong>19 200 ₽</strong>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Shell>
  );
}

ReactDOM.createRoot(document.getElementById("root")).render(<CashierScreen/>);
