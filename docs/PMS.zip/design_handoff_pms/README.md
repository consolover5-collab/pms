# Handoff: PMS (Property Management System) — Grand Baltic Hotel

## Overview
Это дизайн-пакет для нового бэк-офиса отеля: администратор ресепшн, менеджер, инженер housekeeping и бухгалтер работают в едином интерфейсе. 9 экранов покрывают весь операционный день: дашборд → шахматка → работа с бронями → housekeeping → касса → ночной аудит → настройки.

Целевой стек (обсуждали ранее): **Next.js 16 (app router) + TypeScript + Drizzle ORM + PostgreSQL + Tailwind или vanilla-extract**. Если стек другой — адаптируйте, сохраняя структуру экранов и токены.

## About the Design Files
Файлы в папке `pms/` — **дизайн-референсы, написанные как автономные HTML-прототипы на React (через Babel standalone)**. Это прототипы, показывающие желаемую структуру, поведение и визуал, **не production-код для прямого копирования**.

Задача — **воссоздать эти экраны в целевом кодбейзе** (Next.js + React-компоненты + реальные данные из БД), используя уже существующие в проекте паттерны (routing, data layer, UI kit). Если UI-кита нет — см. раздел «Design Tokens» ниже: там готовые CSS-переменные, которые переносятся в `globals.css` один в один.

## Fidelity
**High-fidelity.** Все цвета, шрифты, spacing, радиусы, тени финальные. Воссоздавайте пиксель-в-пиксель. Используйте `Inter` для текста и `JetBrains Mono` для числовых колонок / номеров броней.

## Screens / Views

### 1. Dashboard (`pms/dashboard.html` → `pms/dashboard.jsx`)
**Назначение:** командный центр смены. Ресепшн видит день целиком.

Layout сверху вниз:
- Page head: «Доброе утро, Анна» + биз-дата + actions (Обновить / Отчёт смены / Запустить аудит)
- **KPI row (grid g4):** Загрузка 64% | ADR 7 400 ₽ | RevPAR 4 736 ₽ | Гостей 245
- **Grid g4 (2+2):** Occupancy donut + HK stackbar
- **Grid g2:** Arrivals table | Departures table (на сегодня)
- **Grid g3:** Alerts | Forecast chart 7д | Mini-matrix 184 номеров

Ключевые виджеты:
- **Donut** с четырьмя сегментами (occupied / vacant / OOO / OOS) — CSS conic-gradient.
- **HK stackbar** — 6 сегментов одной горизонтальной полосой + легенда с числами.
- **Forecast:** bar-chart 7 дней с пунктирной линией 100% capacity; overbooking-день (22 апр) красным сверху.
- **Mini-matrix:** 184 квадратика 12×12 px в 24-колоночной сетке.

### 2. Tape Chart (`pms/tape.html` → `pms/tape.jsx`)
**Назначение:** шахматка на 14 дней, перетаскивание броней.

Layout:
- Horizontal scroll; sticky первая колонка (номер) и первая строка (даты).
- Группировка по типу номера (SUITE → JR → DLX → TWN → STD), схлопываемые группы.
- Колонки: 90px на день × 14 = 1260 px + 180 px на лейбл номера.
- Строка номера: слева дот HK-статуса + номер + тип.
- Brand-bars: позиционируются absolute внутри полосы дней, с «половинным» отступом на заезд/отъезд (`DAY_W * 0.4`).

Цвета баров = статусам бронирований:
- confirmed → синий (`--confirmed`)
- checked-in → зелёный
- checked-out → серый
- cancelled → красный + линия насквозь (`text-decoration:line-through`)
- no-show → оранжевый
- ooo → `repeating-linear-gradient` диагональ

### 3. Bookings list (`pms/bookings.html` → `pms/bookings.jsx`)
**Назначение:** полный список броней с фильтрами.

- Tabs по статусу (Все / Подтверждённые / В отеле / Выехали / No-show / Отменённые) с количеством.
- Filter bar: поиск + chips (даты, тип, источник, VIP, С балансом).
- Table columns: checkbox | № брони | Гость (avatar+name+VIP) | Номер·Тип | Заезд | Выезд | Ноч | Источник | Тариф | Статус | Сумма | Баланс (красный если >0) | actions menu.
- Row click → `booking-detail`.

### 4. Booking detail (`pms/booking-detail.html` → `pms/booking-detail.jsx`)
**Самый важный экран. Multi-window folio.**

Header: avatar 52×52 + имя + VIP-бейдж + CORP-бейдж + конфирмация + основные даты + actions (Счёт / Check-out).

Tabs: Финансы (default) | Проживание | Услуги | История | Заметки.

**Finances tab — Grid 1fr / 320px:**
- Left: каскад «folio windows» (окна счёта). Каждое окно = отдельный payer (гость / компания). Структура окна:
  - Header: «Окно A · Room & Taxes» + payer + кнопки (Начисление / Платёж / ⋮)
  - Table: Date | Description | Qty | Amt | ⋮
  - Footer: Начислено / Оплачено / **Баланс** (красный если >0)
- Right column: 4 карточки:
  - Итого по брони (суммы всех окон + кнопка Принять платёж)
  - Гость (ID, email, phone, компания, LTV)
  - Предпочтения (3 строки с эмодзи)
  - Activity timeline (dot + line + когда/кто/что)

### 5. Housekeeping (`pms/housekeep.html` → `pms/housekeep.jsx`)
**Kanban-борд** по 6 колонкам (Dirty / Pickup / Clean / Inspected / OOO / OOS). Каждая карточка:
- № номера (моно-шрифт) + тип
- Гость (если есть)
- Tags: «к выезду» / «заезд» / «VIP» / «Срочно»
- drag-n-drop между колонками.

Ниже таблица назначений горничным с progress-bar.

### 6. Night Audit (`pms/audit.html` → `pms/audit.jsx`)
**5-шаговый wizard** (верхний stepper). Текущий — шаг 3 «Сверка касс».
- Table: касса | кассир | открыта | закрыта | PMS vs Z-отчёт | Δ | статус.
- Красная alert-карточка при расхождении.
- Side: чек-лист дня + предварительные итоги.

### 7. Cashier (`pms/cashier.html` → `pms/cashier.jsx`)
- KPI row (4): Оборот | Карта | Нал | CORP
- Table операций смены + side-panel: Quick actions, Сверка, Открытые депозиты
- Крупная кнопка «Закрыть смену» в хедере

### 8. Profiles (`pms/profiles.html` → `pms/profiles.jsx`)
Таблица гостей: ID | имя+VIP | страна | компания | контакты | проживаний | LTV | последний | ⋮.

### 9. New booking wizard (`pms/new.html` → `pms/new.jsx`)
5 шагов (Даты → Гость → Тариф → Оплата → Подтверждение). На текущем шаге — выбор категории номера, карточки с ценой и availability, side-panel «Сводка брони» + AI-подсказки.

### 10. Settings (`pms/config.html` → `pms/config.jsx`)
Sidebar-навигация разделов + форма параметров отеля (название, ИНН, таймзона, валюта, check-in/out default и т.д.).

## Shared chrome (на всех экранах)
`pms/shell.jsx` экспортирует `<Shell current="...">`:
- **Sidebar** (220px wide / 56px narrow): лого «GB» + 3 секции навигации (Главное / Операции / Система) + профиль снизу.
- **Topbar** (52px): breadcrumbs, searchbox (открывает ⌘K), биз-дата chip, Новая бронь (primary), колокольчик, theme toggle.
- **Command Palette** (⌘K / Ctrl+K): модалка 560px с фильтрацией и стрелками ↑↓ Enter. Группы: Переход / Действия / Поиск.
- **Tweaks panel** (bottom-right): плотность / сайдбар / акцент / тема. Состояние сохраняется в localStorage + postMessage в parent.

## Interactions & Behavior
- **Навигация:** `<a href="bookings.html">`. В реальном приложении заменить на Next.js `<Link>` + routes (`/bookings`, `/bookings/[id]` и т.д.).
- **Command palette:** keyboard ⌘K глобально; Escape закрывает; ↑↓ переключает selection; Enter переходит по `href`.
- **Theme toggle:** atomic attribute `data-theme="dark"` на `<html>`. До рендера React ставится из localStorage — чтобы не было вспышки.
- **Row click в таблицах** → detail page. Клик на checkbox / action menu не триггерит переход (stopPropagation).
- **Tape-chart bars:** клик открывает booking-detail. OOO не кликабельны.
- **Folio windows:** кнопки «Начисление» и «Платёж» должны открывать модалки с формами (в прототипе заглушки).

## State Management
В целевом приложении:
- **Routing state** — Next.js app router, serverActions для мутаций.
- **Data layer** — RSC + React Query для клиентских кусков (tape-chart drag, filters).
- **Tape chart state:** drag-n-drop через `@dnd-kit`. При drop — server action на перенос брони. Optimistic update обязателен.
- **Folio windows:** один booking → N окон. Модель: `folioWindow { id, bookingId, payer, lines[], paymentMethod }`.
- **Command palette:** глобальный state через `useContext` или `zustand`.
- **Tweaks:** localStorage + CSS custom properties, без перезагрузки.

## Design Tokens

Все токены в `pms/shell.css`, готовы к копированию. Краткая выжимка:

### Colors (light)
```
--bg:               #ffffff
--bg-subtle:        #fafafa
--bg-sunken:        #f5f5f5
--surface:          #ffffff
--surface-2:        #f3f4f6
--fg:               #0a0a0a
--muted:            #6b7280
--muted-2:          #9ca3af
--border:           #e5e7eb
--border-strong:    #d1d5db

--accent:           #2563eb
--accent-hover:     #1d4ed8
--accent-soft:      #eff6ff

-- Semantic statuses
--confirmed:  #2563eb   bg #dbeafe  fg #1e40af
--checked-in: #16a34a   bg #dcfce7  fg #166534
--checked-out:#6b7280   bg #f3f4f6  fg #1f2937
--cancelled:  #dc2626   bg #fee2e2  fg #991b1b
--no-show:    #ea580c   bg #ffedd5  fg #9a3412

-- Housekeeping
--hk-clean:     #16a34a
--hk-dirty:     #ea580c
--hk-pickup:    #eab308
--hk-inspected: #059669
--hk-ooo:       #525252
--hk-oos:       #dc2626
```

### Colors (dark)
См. `[data-theme="dark"]` блок в `shell.css` — все токены переопределены.

### Typography
- Sans: `Inter`, weights 400/500/600/700, с feature settings `"cv11","ss01"`
- Mono: `JetBrains Mono` 400/500 (все числовые колонки, номера броней, ID, время)
- Base size: 13px (medium density); 12px compact; 14px cozy
- Line-height: 1.45
- Antialiased

### Spacing
- card-head: `10px 14px`
- card-body: `12px 14px`
- table th/td: `7px 12px`
- topbar: 52px высота, 16px паддинг
- sidebar: 220/56px, items 6px 8px
- grid gap: 12–14px

### Radius
- `--radius`: 8px (cards)
- `--radius-sm`: 6px (buttons, inputs)
- `--radius-lg`: 12px (palette)
- badges 4px, chips 4px

### Shadows
- `--shadow-sm`: `0 1px 2px rgba(0,0,0,.04)`
- `--shadow`: `0 1px 3px rgba(0,0,0,.06), 0 1px 2px rgba(0,0,0,.04)`
- `--shadow-lg`: `0 10px 30px rgba(0,0,0,.12)` (palette, drawers)

### Components

**Button sizes:** xs (11px/2–6px), sm (11.5px/3–8px), default (12.5px/5–10px). Variants: default, primary (accent bg), danger (red), ghost (no bg).

**Badges:** 11px, 2–7px padding, radius 4px. 6px круглый dot внутри (`currentColor`). Variants: `confirmed`, `checked-in`, `checked-out`, `cancelled`, `no-show`, `hk-*`, `outline`, `vip` (amber).

**Table:** `.t` — header bg `--bg-subtle`, uppercase 11px muted, sticky top; rows 7px paddings, hover `--surface-hover`, last-child без border.

**KPI tile:** 80px min-height, label 10.5px uppercase muted, value 24px bold, footer with trend arrow.

## Data Model (для seed + API)

Источник истины — `pms/data.js`. Соответствует ранее сгенерированному seed-скрипту (Grand Baltic Hotel, 184 номера, биз-дата 2026-04-20).

### Essential tables
```
hotels          { id, name, currency, business_date, timezone }
room_types      { code, name, total }   -- STD, TWN, DLX, JR, SUITE
rooms           { n, type_code, floor, hk_status, oo_status }
rate_plans      { code, name }          -- BAR, CORP, PKG
guests          { id, name, country, email, phone, vip, company, pref, ltv, stays_count }
bookings        { conf_no, guest_id, room_no, arr, dep, nights, status,
                  source, rate_plan_code, adults, children, rate_amount, notes }
folio_windows   { id, booking_id, label, payer, seq (A/B/…) }
folio_lines     { id, window_id, date, desc, qty, amount }
payments        { id, window_id, amount, method, time, cashier_id, shift_id }
shifts          { id, cashier_id, opened_at, closed_at, starting_cash, z_report }
hk_tasks        { room_n, assigned_to, status, priority, floor, shift_id }
alerts          { id, severity, title, subtitle, created_at, resolved_at }
audit_logs      { id, biz_date, step, payload, operator_id, started_at, finished_at }
```

### Key statuses enum
- booking.status: `confirmed | checked-in | checked-out | cancelled | no-show | due-out`
- hk.status: `dirty | pickup | clean | inspected | ooo | oos`

## Implementation Plan (рекомендуемый порядок)

1. **Фундамент:** перенести `shell.css` как `globals.css`, настроить шрифты, тему.
2. **App shell:** Sidebar + Topbar + Command Palette как серверные + клиентские компоненты.
3. **Seed DB:** скормить Claude Code seed-промпт (уже есть в истории); `pnpm seed`.
4. **Dashboard** — первый экран, т.к. использует все виджеты-примитивы.
5. **Bookings list + Booking detail** — CRUD цикл, folio mutations.
6. **Tape chart** — самый сложный, делать последним после стабилизации данных.
7. **HK board, Cashier, Night Audit, Profiles, Settings** — параллельно разными людьми.

## Files in this bundle

```
pms/
├── shell.css              ← дизайн-токены, все компонентные стили
├── shell.jsx              ← Sidebar, Topbar, Palette, Tweaks, Shell HOC
├── icons.jsx              ← 30+ stroke-икон (16px default)
├── data.js                ← seed data (1:1 с seed-промптом)
│
├── dashboard.html + .jsx
├── tape.html + .jsx
├── bookings.html + .jsx
├── booking-detail.html + .jsx
├── housekeep.html + .jsx
├── audit.html + .jsx
├── cashier.html + .jsx
├── profiles.html + .jsx
├── new.html + .jsx
└── config.html + .jsx
```

## Запуск прототипов локально
```
cd design_handoff_pms/pms
python3 -m http.server 8080
# открыть http://localhost:8080/dashboard.html
```

## Что НЕ переносить из прототипа
- `Babel standalone` — production-код должен быть скомпилирован.
- `script type="text/babel"` — заменить на нативные ES-модули.
- Inline `<script>` с восстановлением темы — перенести в Next.js `<head>` через `dangerouslySetInnerHTML` или cookie-based theme detection.
- `window.claude.complete` не используется (AI-хинты в New booking — плейсхолдер).

## Контакты
Все вопросы по дизайн-решениям — назад в дизайн-трек.
